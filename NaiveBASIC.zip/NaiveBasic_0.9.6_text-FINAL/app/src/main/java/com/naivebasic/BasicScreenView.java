package com.naivebasic;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Color;
import android.util.AttributeSet;
import android.view.View;

public class BasicScreenView extends View {
    private final Paint paint = new Paint();
    // BASIC always renders into a fixed logical viewport; Android only scales that viewport.
    private int viewportW(){ return (mode==1||mode==3)?240:320; }
    private int viewportH(){ return (mode==1||mode==3)?320:240; }
    // The BASIC viewport is logical, but on larger Android displays it fills the
    // complete available surface. At the native 320x240/240x320 size the scale
    // remains uniform, so the original pixel geometry is not distorted.
    private float scaleX(){ return getWidth()/(float)viewportW(); }
    private float scaleY(){ return getHeight()/(float)viewportH(); }
    private float viewportLeft(){ return 0f; }
    private float viewportTop(){ return 0f; }
    private final byte[][] chars = new byte[40][80];
    private final byte[][] fg = new byte[40][80];
    private final byte[][] bg = new byte[40][80];
    private int mode=0, cols=40, rows=30, cellW=8, cellH=8, cursorX=0, cursorY=0;
    private boolean compact=false;
private int inkColor=7, paperColor=0;
    private boolean hasOutput=false;

    public BasicScreenView(Context c, AttributeSet a){super(c,a);paint.setAntiAlias(false);resetScreen();}
    public BasicScreenView(Context c){this(c,null);}

    public void resetScreen(){setScreenMode(0);clear();}
    public void setScreenMode(int m){setScreenMode(m,compact);}
    public void setScreenMode(int m, boolean c){mode=m;compact=c;updateGrid();cursorX=0;cursorY=0;clear();}
    private void updateGrid(){ if(mode==1||mode==3){cols=compact?60:30;rows=40;}else{cols=compact?80:40;rows=30;} cellW=compact?4:8; cellH=8; }
    public void setCompact(boolean on){compact=on; updateGrid(); cursorX=0; cursorY=0; clear();}
    private void clear(){
        for(int y=0;y<40;y++)for(int x=0;x<80;x++){chars[y][x]=32;fg[y][x]=(byte)inkColor;bg[y][x]=(byte)paperColor;}
        hasOutput=false;invalidate();
    }

    public boolean hasOutput(String s){return hasOutput && s!=null && s.length()>0;}
    public int logicalX(int px){float sx=scaleX();return clamp((int)((px-viewportLeft())/sx),0,viewportW()-1);}
    public int logicalY(int py){float sy=scaleY();return clamp((int)((py-viewportTop())/sy),0,viewportH()-1);}
    private int clamp(int v,int a,int b){return v<a?a:v>b?b:v;}

    public void printAt(int row,int col,String s){cursorY=clamp(row,0,rows-1);cursorX=clamp(col,0,cols-1);printText(s);}
    public void printText(String s){
        if(s==null)return;hasOutput=true;
        String[] parts=s.replace("\r","").split("\n",-1);
        for(int p=0;p<parts.length;p++){
            String line=parts[p];
            for(int i=0;i<line.length();i++){
                char ch=line.charAt(i);
                if(ch=='\t'){cursorX=(cursorX+4)&~3; if(cursorX>=cols){newline();} continue;}
                put((byte)encode(ch));
            }
            if(p<parts.length-1)newline();
        }
        invalidate();
    }
    private void put(byte b){
        chars[cursorY][cursorX]=b;
        fg[cursorY][cursorX]=(byte)inkColor;
        bg[cursorY][cursorX]=(byte)paperColor;
        cursorX++;if(cursorX>=cols)newline();
    }
    private void newline(){cursorX=0;cursorY++;if(cursorY>=rows){for(int y=1;y<rows;y++)System.arraycopy(chars[y],0,chars[y-1],0,cols);for(int x=0;x<cols;x++){chars[rows-1][x]=32;fg[rows-1][x]=(byte)inkColor;bg[rows-1][x]=(byte)paperColor;}cursorY=rows-1;}}

    private int encode(char c){
        if(c<256)return c;
        // KOI8-R-compatible Cyrillic mapping for common Russian letters.
        switch(c){case 'А':return 0xE1;case 'Б':return 0xE2;case 'В':return 0xF7;case 'Г':return 0xE7;case 'Д':return 0xE4;case 'Е':return 0xE5;case 'Ё':return 0xB3;case 'Ж':return 0xF6;case 'З':return 0xFA;case 'И':return 0xE9;case 'Й':return 0xEA;case 'К':return 0xEB;case 'Л':return 0xEC;case 'М':return 0xED;case 'Н':return 0xEE;case 'О':return 0xEF;case 'П':return 0xF0;case 'Р':return 0xF2;case 'С':return 0xF3;case 'Т':return 0xF4;case 'У':return 0xF5;case 'Ф':return 0xE6;case 'Х':return 0xE8;case 'Ц':return 0xE3;case 'Ч':return 0xFE;case 'Ш':return 0xFB;case 'Щ':return 0xFD;case 'Ъ':return 0xFF;case 'Ы':return 0xF9;case 'Ь':return 0xF8;case 'Э':return 0xFC;case 'Ю':return 0xE0;case 'Я':return 0xF1;
        case 'а':return 0xC1;case 'б':return 0xC2;case 'в':return 0xD7;case 'г':return 0xC7;case 'д':return 0xC4;case 'е':return 0xC5;case 'ё':return 0xA3;case 'ж':return 0xD6;case 'з':return 0xDA;case 'и':return 0xC9;case 'й':return 0xCA;case 'к':return 0xCB;case 'л':return 0xCC;case 'м':return 0xCD;case 'н':return 0xCE;case 'о':return 0xCF;case 'п':return 0xD0;case 'р':return 0xD2;case 'с':return 0xD3;case 'т':return 0xD4;case 'у':return 0xD5;case 'ф':return 0xC6;case 'х':return 0xC8;case 'ц':return 0xC3;case 'ч':return 0xDE;case 'ш':return 0xDB;case 'щ':return 0xDD;case 'ъ':return 0xDF;case 'ы':return 0xD9;case 'ь':return 0xD8;case 'э':return 0xDC;case 'ю':return 0xC0;case 'я':return 0xD1;default:return '?';}
    }

    
    public void setInkColor(int c){ inkColor = clamp(c); invalidate(); }
    public void setPaperColor(int c){ paperColor = clamp(c); invalidate(); }
    public void tab(int n){ cursorX += n; while(cursorX >= cols) newline(); invalidate(); }
    private int clamp(int c){ return c<0?0:(c>255?255:c); }
protected void onDraw(Canvas c){
        super.onDraw(c);
        float sx=scaleX(),sy=scaleY();
        float ox=viewportLeft(),oy=viewportTop();
        c.drawColor(palette(bg[0][0]&255));
        for(int y=0;y<rows;y++)for(int x=0;x<cols;x++){
            float px=ox+x*cellW*sx, py=oy+y*8*sy;
            paint.setColor(palette(bg[y][x]&255));
            paint.setStyle(Paint.Style.FILL);
            c.drawRect(px,py,px+cellW*sx,py+8*sy,paint);
            drawGlyph(c,chars[y][x]&255,px,py,sx,sy,palette(fg[y][x]&255));
        }
    }

    private int palette(int index){
        // 256-color EGA-style logical palette:
        // 0..15 standard colors, 16..255 extended RGB cube/greys.
        if(index<16){
            final int[] p={Color.BLACK,Color.BLUE,Color.GREEN,Color.CYAN,
                Color.RED,Color.MAGENTA,Color.YELLOW,Color.WHITE,
                Color.rgb(64,64,64),Color.rgb(64,64,255),Color.rgb(64,255,64),
                Color.rgb(64,255,255),Color.rgb(255,64,64),Color.rgb(255,64,255),
                Color.rgb(255,255,64),Color.rgb(255,255,255)};
            return p[index];
        }
        int n=index-16;
        if(n>=216) {
            int g=8+(n-216)*10;
            if(g>255)g=255;
            return Color.rgb(g,g,g);
        }
        int r=(n/36)*51, g=((n/6)%6)*51, b=(n%6)*51;
        return Color.rgb(r,g,b);
    }

    private void drawGlyph(Canvas c,int code,float x,float y,float sx,float sy,int color){
        paint.setColor(color);
        paint.setStyle(Paint.Style.FILL);
        int[] g=Font8x8.glyph(code);
        if(!compact){
            for(int r=0;r<8;r++){int bits=g[r];for(int b=0;b<8;b++)
                if((bits&(1<<(7-b)))!=0)c.drawRect(x+b*sx,y+r*sy,x+(b+1)*sx,y+(r+1)*sy,paint);}
        } else {
            for(int r=0;r<8;r++){int bits=g[r];for(int b=0;b<8;b+=2){
                boolean on=((bits&(1<<(7-b)))!=0)||((bits&(1<<(6-b)))!=0);
                if(on)c.drawRect(x+(b/2)*sx,y+r*sy,x+(b/2+1)*sx,y+(r+1)*sy,paint);}}
        }
    }

}
