package com.naivebasic;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.pm.ActivityInfo;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.Window;
import android.view.WindowManager;
import android.content.res.Configuration;
import android.widget.Button;
import android.widget.EditText;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioTrack;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.concurrent.CountDownLatch;

public class MainActivity extends Activity implements BasicInterpreter.ScreenProvider, SensorEventListener {
    private int lastKey = 0;
    private boolean touchDown = false;
    private volatile boolean programRunning = false;
    private volatile BasicInterpreter runningInterpreter = null;
    private volatile Thread runningThread = null;
    private int touchX = 0;
    private int touchY = 0;
    private int giro = 0;
    private int screenMode = 0;

    private EditText editor;
    private View editorScreen;
    private BasicScreenView runScreen;
    private View aboutScreen;
    private String pendingInput = "";

    private SensorManager sensorManager;
    private Sensor accelerometer;
    private final Handler backHandler = new Handler();
    private boolean backHeld = false;
    private final Runnable longBack = new Runnable() {
        public void run() {
            if (backHeld && programRunning) {
                backHeld = false;
                returnToEditor();
            }
        }
    };

    public void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.main);
        installBundledPrograms();

        editorScreen = findViewById(R.id.editor_screen);
        aboutScreen = findViewById(R.id.about_screen);
        editor = (EditText)findViewById(R.id.editor);
        runScreen = (BasicScreenView)findViewById(R.id.run_screen);

        editor.setText(
            "10 REM Naive BASIC 0.8\n" +
            "20 PRINT \"HELLO, WORLD!\"\n" +
            "30 FOR I=1 TO 5\n" +
            "40 PRINT \"COUNT: \" + I\n" +
            "50 NEXT I\n" +
            "60 END\n"
        );

        ((Button)findViewById(R.id.run)).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { runProgram(); }
        });
        ((Button)findViewById(R.id.menu)).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { showMainMenu(); }
        });

        editor.setFocusableInTouchMode(true);
        editor.setOnKeyListener(new View.OnKeyListener() {
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (event.getAction() == KeyEvent.ACTION_DOWN) lastKey = spectrumKeyCode(keyCode);
                return false;
            }
        });

        runScreen.setFocusableInTouchMode(true);
        runScreen.setOnKeyListener(new View.OnKeyListener() {
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (event.getAction() == KeyEvent.ACTION_DOWN) lastKey = spectrumKeyCode(keyCode);
                return false;
            }
        });
        runScreen.setOnTouchListener(new View.OnTouchListener() {
            public boolean onTouch(View v, MotionEvent event) {
                touchX = mapTouchX((int)event.getX());
                touchY = mapTouchY((int)event.getY());
                touchDown = event.getAction() != MotionEvent.ACTION_UP && event.getAction() != MotionEvent.ACTION_CANCEL;
                return true;
            }
        });
        aboutScreen.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { returnToEditor(); }
        });

        sensorManager = (SensorManager)getSystemService(SENSOR_SERVICE);
        if (sensorManager != null) accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        // Editor follows Android automatic rotation; only the BASIC runtime is forced to landscape.
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED);
        showEditor();
    }

    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        if (runScreen != null) runScreen.invalidate();
    }

    protected void onResume() {
        super.onResume();
        if (sensorManager != null && accelerometer != null)
            sensorManager.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_UI);
    }

    protected void onPause() {
        if (sensorManager != null) sensorManager.unregisterListener(this);
        super.onPause();
    }

    public void onSensorChanged(SensorEvent e) {
        if (e.sensor.getType() != Sensor.TYPE_ACCELEROMETER) return;
        float x=e.values[0], y=e.values[1];
        if (Math.abs(x) > Math.abs(y)) giro = x < 0 ? 0 : 2;
        else giro = y < 0 ? 1 : 3;
    }
    public void onAccuracyChanged(Sensor s, int a) { }

    private void installBundledPrograms() {
        // The bundled tutorial and test are part of the release itself.
        // Always replace these two files when the application starts, while
        // leaving every other user program untouched.
        String[] names = {"uchebnik.bas", "test.bas"};
        for (String name : names) {
            try {
                java.io.InputStream in = getAssets().open("programs/" + name);
                FileOutputStream out = openFileOutput(name, MODE_PRIVATE);
                byte[] buffer = new byte[4096]; int n;
                while ((n=in.read(buffer))>0) out.write(buffer,0,n);
                in.close(); out.close();
            } catch (Exception ignored) { }
        }
    }

    private void showEditor() {
        clearRunFullscreen();
        editorScreen.setVisibility(View.VISIBLE); runScreen.setVisibility(View.GONE); aboutScreen.setVisibility(View.GONE);
    }
    private void showRunScreen() {
        editorScreen.setVisibility(View.GONE); aboutScreen.setVisibility(View.GONE); runScreen.setVisibility(View.VISIBLE);
        runScreen.bringToFront(); runScreen.requestFocus(); runScreen.invalidate();
    }
    private void showAbout() { editorScreen.setVisibility(View.GONE); runScreen.setVisibility(View.GONE); aboutScreen.setVisibility(View.VISIBLE); }
    private void returnToEditor() {
        programRunning=false;
        backHeld=false;
        backHandler.removeCallbacks(longBack);
        BasicInterpreter bi = runningInterpreter;
        if (bi != null) bi.requestStop();
        Thread rt = runningThread;
        if (rt != null) rt.interrupt();
        clearRunFullscreen();
        screenMode=0; runScreen.resetScreen();
        // Editor follows Android automatic rotation; only the BASIC runtime is forced to landscape.
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED);
        showEditor();
    }

    private void setRunFullscreen() {
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
    }

    private void clearRunFullscreen() {
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
    }

    public int getKey() { int k=lastKey; lastKey=0; return k; }
    public boolean isTouch(){return touchDown;}
    public int getTouchX(){return touchX;}
    public int getTouchY(){return touchY;}
    public int getScreenX(){return screenMode==1||screenMode==3?240:320;}
    public int getScreenY(){return screenMode==1||screenMode==3?320:240;}
    public int getGiro(){return giro;}

    public void setScreen(final int mode, final int charset) throws Exception {
        if(mode<0||mode>3) throw new Exception("Bad SCREEN mode");
        if(charset<0||charset>1) throw new Exception("Bad SCREEN charset");
        screenMode=mode;
        final CountDownLatch done=new CountDownLatch(1);
        runOnUiThread(new Runnable(){ public void run(){
            try {
                if (!programRunning) return;
                int o;
                if(mode==0) o=ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE;
                else if(mode==1) o=ActivityInfo.SCREEN_ORIENTATION_PORTRAIT;
                else if(mode==2) o=ActivityInfo.SCREEN_ORIENTATION_REVERSE_LANDSCAPE;
                else o=ActivityInfo.SCREEN_ORIENTATION_REVERSE_PORTRAIT;
                setRequestedOrientation(o); runScreen.setScreenMode(mode, charset==1);
            } finally { done.countDown(); }
        }});
        try { done.await(); } catch(InterruptedException e){Thread.currentThread().interrupt();}
    }

    public void setInk(final int color){ if(runScreen!=null) runOnUiThread(new Runnable(){ public void run(){ runScreen.setInkColor(color); }}); }
    public void setPaper(final int color){ if(runScreen!=null) runOnUiThread(new Runnable(){ public void run(){ runScreen.setPaperColor(color); }}); }
    public void tab(final int count){ if(runScreen!=null) runOnUiThread(new Runnable(){ public void run(){ runScreen.tab(count); }}); }
    public void plot(final int x, final int y, final int color){ if(runScreen!=null) runScreen.plotPoint(x,y,color); }
    public void draw(final int dx, final int dy, final int color) throws Exception { if(runScreen!=null) runScreen.draw(dx,dy,color); }
    public void drawLine(final int x1, final int y1, final int x2, final int y2) throws Exception { if(runScreen!=null) runScreen.drawLine(x1,y1,x2,y2); }
    public void drawLineTo(final int x2, final int y2) throws Exception { if(runScreen!=null) runScreen.drawLineTo(x2,y2); }
    public void circle(final int xc, final int yc, final int rx, final int ry, final boolean filled) throws Exception { if(runScreen!=null) runScreen.circle(xc,yc,rx,ry,filled); }
    public void triangle(final int x1, final int y1, final int x2, final int y2, final int x3, final int y3, final boolean filled) throws Exception { if(runScreen!=null) runScreen.triangle(x1,y1,x2,y2,x3,y3,filled); }
    public void paintArea(final int x, final int y) throws Exception { if(runScreen!=null) runScreen.paintArea(x,y); }

    public void print(String s){ if(runScreen!=null) runOnUiThread(new PrintTask(s,false,0,0)); }
    public void printAt(int row,int col,String s){ if(runScreen!=null) runOnUiThread(new PrintTask(s,true,row,col)); }
    private class PrintTask implements Runnable { String s; boolean at; int r,c; PrintTask(String x,boolean a,int rr,int cc){s=x;at=a;r=rr;c=cc;} public void run(){if(at)runScreen.printAt(r,c,s);else runScreen.printText(s);}}

    private int mapTouchX(int x){return runScreen.logicalX(x);}
    private int mapTouchY(int y){return runScreen.logicalY(y);}

    private void playTone(double frequency, double duration, double volume) throws Exception {
        if(duration <= 0 || frequency <= 0) return;
        ArrayList<NoteEvent> tone = new ArrayList<NoteEvent>();
        tone.add(new NoteEvent(0.0, duration, frequency, Math.max(0.0, Math.min(1.0, volume))));
        renderPlay(tone);
    }

    public void beep(double duration, double pitch) throws Exception {
        playTone(261.625565 * Math.pow(2.0, pitch / 12.0), duration, 1.0);
    }

    public void play(String[] patterns) throws Exception {
        if (patterns == null || patterns.length == 0) return;
        // Spectrum 128 PLAY has up to three AY voices. Here the Android renderer
        // mixes the first three musical strings into one PCM stream.
        ArrayList<NoteEvent> all = new ArrayList<NoteEvent>();
        for (int i=0;i<patterns.length && i<3;i++) parsePlayPattern(patterns[i], all, i);
        renderPlay(all);
    }

    private static class NoteEvent {
        double start, duration, freq, volume;
        NoteEvent(double s,double d,double f,double v){start=s;duration=d;freq=f;volume=v;}
    }

    private void parsePlayPattern(String src, ArrayList<NoteEvent> out, int channel) throws Exception {
        if(src==null) return;
        String s=src.trim();
        int octave=4, length=5, tempo=120, volume=15;
        double time=0;
        java.util.ArrayList<Double> repeatStart=new java.util.ArrayList<Double>();
        java.util.ArrayList<Integer> repeatPos=new java.util.ArrayList<Integer>();
        for(int i=0;i<s.length();i++){
            char c=s.charAt(i);
            if(c==' ' || c=='\t') continue;
            if(c=='!'){ int j=s.indexOf('!',i+1); if(j<0) throw new Exception("PLAY comment"); i=j; continue; }
            if(c=='('){ repeatPos.add(Integer.valueOf(i)); repeatStart.add(Double.valueOf(time)); continue; }
            if(c==')'){
                if(!repeatPos.isEmpty()){
                    int open=repeatPos.remove(repeatPos.size()-1).intValue();
                    double st=repeatStart.remove(repeatStart.size()-1).doubleValue();
                    // Repeat once, matching the common Spectrum bracket form.
                    // Avoid recursively replaying nested brackets.
                    String sub=s.substring(open+1,i);
                    ArrayList<NoteEvent> tmp=new ArrayList<NoteEvent>();
                    parsePlayPattern(sub,tmp,channel);
                    double shift=time-st;
                    for(NoteEvent e:tmp) out.add(new NoteEvent(st+e.start+shift,e.duration,e.freq,e.volume));
                    time += shift;
                }
                continue;
            }
            if(c=='T' || c=='t'){
                int[] nr=readNumber(s,i+1); if(nr[0]<0) throw new Exception("PLAY tempo expected");
                tempo=nr[0]; if(tempo<60||tempo>240) throw new Exception("PLAY tempo 60..240");
                i=nr[1]-1; continue;
            }
            if(c=='O' || c=='o'){
                int[] nr=readNumber(s,i+1); if(nr[0]<0) throw new Exception("PLAY octave expected");
                octave=nr[0]; if(octave<0||octave>8) throw new Exception("PLAY octave 0..8");
                i=nr[1]-1; continue;
            }
            if(c=='V' || c=='v'){
                int[] nr=readNumber(s,i+1); if(nr[0]<0) throw new Exception("PLAY volume expected");
                volume=nr[0]; if(volume<0||volume>15) throw new Exception("PLAY volume 0..15");
                i=nr[1]-1; continue;
            }
            if(Character.isDigit(c)){
                int[] nr=readNumber(s,i); int n=nr[0];
                if(n<1||n>12) throw new Exception("PLAY note length 1..12");
                length=n; i=nr[1]-1; continue;
            }
            if(c=='&'){ time += playLength(length,tempo); continue; }
            if(c=='N'){ // numeric separator; ignored as a structural marker
                continue;
            }
            if(c=='H'){ break; }
            int accidental=0;
            if(c=='#' || c=='$'){
                accidental=c=='#'?1:-1;
                i++;
                if(i>=s.length()) throw new Exception("PLAY note expected");
                c=s.charAt(i);
            }
            int semitone=noteSemitone(c);
            if(semitone<0) throw new Exception("Unknown PLAY note: "+c);
            int baseOct=Character.isUpperCase(c)?octave+1:octave;
            double pitch=12.0*(baseOct-4)+semitone+accidental;
            double freq=261.625565*Math.pow(2.0,pitch/12.0);
            double dur=playLength(length,tempo);
            out.add(new NoteEvent(time,dur,freq,volume/15.0));
            time+=dur;
        }
    }

    private int[] readNumber(String s,int p){
        if(p>=s.length() || !Character.isDigit(s.charAt(p))) return new int[]{-1,p};
        int n=0,i=p;
        while(i<s.length()&&Character.isDigit(s.charAt(i))){n=n*10+(s.charAt(i)-'0');i++;}
        return new int[]{n,i};
    }

    private int noteSemitone(char c){
        switch(Character.toLowerCase(c)){
            case 'c': return 0; case 'd': return 2; case 'e': return 4;
            case 'f': return 5; case 'g': return 7; case 'a': return 9;
            case 'b': return 11; default:return -1;
        }
    }

    private double playLength(int n,int tempo){
        double beats;
        switch(n){
            case 1:beats=.25;break; case 2:beats=.375;break; case 3:beats=.5;break;
            case 4:beats=.75;break; case 5:beats=1;break; case 6:beats=1.5;break;
            case 7:beats=2;break; case 8:beats=3;break; case 9:beats=4;break;
            case 10:beats=.3333333333;break; case 11:beats=.6666666667;break;
            case 12:beats=1.3333333333;break; default:beats=1;break;
        }
        return beats*60.0/tempo;
    }

    private void renderPlay(ArrayList<NoteEvent> events) throws Exception {
        if(events.isEmpty()) return;
        final int rate=22050;
        double end=0;
        for(NoteEvent e:events) end=Math.max(end,e.start+e.duration);
        int count=(int)Math.ceil(end*rate)+1;
        if(count<=1) return;
        short[] pcm=new short[count];
        for(NoteEvent e:events){
            int a=(int)(e.start*rate), b=Math.min(count,(int)((e.start+e.duration)*rate));
            for(int i=a;i<b;i++){
                double t=(i-a)/(double)rate;
                double env=Math.min(1.0,t*80.0)*Math.min(1.0,(e.duration-t)*80.0);
                double sample=Math.sin(2*Math.PI*e.freq*t)*e.volume*0.35*env;
                int v=pcm[i]+(int)(sample*32767);
                pcm[i]=(short)Math.max(Short.MIN_VALUE,Math.min(Short.MAX_VALUE,v));
            }
        }
        AudioTrack track=new AudioTrack(AudioManager.STREAM_MUSIC,rate,AudioFormat.CHANNEL_OUT_MONO,
                AudioFormat.ENCODING_PCM_16BIT,pcm.length*2,AudioTrack.MODE_STATIC);
        track.write(pcm,0,pcm.length);
        track.play();
        long wait=(long)(end*1000)+100;
        Thread.sleep(wait);
        try{track.stop();}finally{track.release();}
    }

    private int spectrumKeyCode(int k) {
        switch(k){
            case KeyEvent.KEYCODE_0:return 48; case KeyEvent.KEYCODE_1:return 49; case KeyEvent.KEYCODE_2:return 50;
            case KeyEvent.KEYCODE_3:return 51; case KeyEvent.KEYCODE_4:return 52; case KeyEvent.KEYCODE_5:return 53;
            case KeyEvent.KEYCODE_6:return 54; case KeyEvent.KEYCODE_7:return 55; case KeyEvent.KEYCODE_8:return 56;
            case KeyEvent.KEYCODE_9:return 57; case KeyEvent.KEYCODE_DPAD_LEFT:return 8; case KeyEvent.KEYCODE_DPAD_RIGHT:return 9;
            case KeyEvent.KEYCODE_DPAD_UP:return 10; case KeyEvent.KEYCODE_DPAD_DOWN:return 11;
            case KeyEvent.KEYCODE_ENTER:return 13; case KeyEvent.KEYCODE_DEL:return 127; case KeyEvent.KEYCODE_SPACE:return 32;
            default:return k;
        }
    }

    public boolean dispatchKeyEvent(KeyEvent event){
        if(event.getKeyCode()==KeyEvent.KEYCODE_BACK && runScreen.getVisibility()==View.VISIBLE){
            if(event.getAction()==KeyEvent.ACTION_DOWN && programRunning){
                if(event.getRepeatCount()==0){
                    backHeld=true;
                    backHandler.removeCallbacks(longBack);
                    backHandler.postDelayed(longBack,5000);
                }
                return true;
            }
            if(event.getAction()==KeyEvent.ACTION_UP && programRunning){
                backHeld=false;
                backHandler.removeCallbacks(longBack);
                return true;
            }
        }
        return super.dispatchKeyEvent(event);
    }

    public boolean onKeyDown(int keyCode, KeyEvent event){
        if(keyCode==KeyEvent.KEYCODE_BACK && runScreen.getVisibility()==View.VISIBLE){
            if(programRunning){
                backHeld=true;
                backHandler.removeCallbacks(longBack);
                backHandler.postDelayed(longBack,5000);
                return true;
            }
            returnToEditor(); return true;
        }
        return super.onKeyDown(keyCode,event);
    }

    public boolean onKeyUp(int keyCode, KeyEvent event){
        if(keyCode==KeyEvent.KEYCODE_BACK && runScreen.getVisibility()==View.VISIBLE){
            backHeld=false;
            backHandler.removeCallbacks(longBack);
            return true;
        }
        return super.onKeyUp(keyCode,event);
    }

    public boolean onKeyLongPress(int keyCode, KeyEvent event){
        if(keyCode==KeyEvent.KEYCODE_BACK && runScreen.getVisibility()==View.VISIBLE && programRunning){
            backHeld=false;
            backHandler.removeCallbacks(longBack);
            returnToEditor();
            return true;
        }
        return super.onKeyLongPress(keyCode,event);
    }

    public void onBackPressed(){
        if(runScreen.getVisibility()==View.VISIBLE){
            if(!programRunning) returnToEditor();
            return;
        }
        if(aboutScreen.getVisibility()==View.VISIBLE){returnToEditor();return;}
        super.onBackPressed();
    }

    private void runProgram(){
        lastKey=0; touchDown=false; programRunning=true; screenMode=0;
        setRunFullscreen();
        runScreen.resetScreen();
        // With configChanges enabled, changing orientation no longer recreates the Activity.
        // Therefore RUN remains a single user action even when the editor was portrait.
        try { setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE); } catch(Exception ignored){}
        showRunScreen();
        Thread rt = new Thread(new Runnable(){ public void run(){
            final BasicInterpreter bi=new BasicInterpreter(MainActivity.this);
            runningInterpreter = bi;
            final String result=bi.run(editor.getText().toString());
            runOnUiThread(new Runnable(){ public void run(){
                if (runningInterpreter == bi) {
                    runningInterpreter = null;
                    runningThread = null;
                }
                if (programRunning) {
                    programRunning=false;
                    if(result!=null && result.length()>0 && !runScreen.hasOutput(result)) runScreen.printText(result);
                    runScreen.invalidate();
                }
            }});
        }});
        runningThread = rt;
        rt.start();
    }

    private void showMainMenu(){
        final String[] items={"NEW","SAVE","LOAD","DELETE","AUTHORS"};
        new AlertDialog.Builder(this).setTitle("PROGRAM").setItems(items,new DialogInterface.OnClickListener(){
            public void onClick(DialogInterface d,int which){
                if(which==0)editor.setText(""); else if(which==1)askSaveName(); else if(which==2)showProgramList(false); else if(which==3)showProgramList(true); else showAbout();
            }}).show();
    }
    private void askSaveName(){
        final EditText field=new EditText(this); field.setSingleLine(true); field.setText("PROGRAM.bas"); field.setSelectAllOnFocus(true); field.requestFocus(); field.setSelection(0,field.getText().length());
        new AlertDialog.Builder(this).setTitle("SAVE PROGRAM").setMessage("Program name").setView(field)
            .setPositiveButton("SAVE",new DialogInterface.OnClickListener(){public void onClick(DialogInterface d,int w){String name=normalizeName(field.getText().toString());if(name==null){showEditorMessage("ERROR: BAD FILE NAME");return;}try{saveProgram(name);showEditorMessage("SAVED: "+name);}catch(Exception e){showEditorMessage("ERROR: "+e.getMessage());}}})
            .setNegativeButton("CANCEL",null).show();
    }
    private void showProgramList(final boolean deleteMode){final String[] names=getProgramNames();if(names.length==0){showEditorMessage("NO PROGRAMS");return;}new AlertDialog.Builder(this).setTitle(deleteMode?"DELETE PROGRAM":"LOAD PROGRAM").setItems(names,new DialogInterface.OnClickListener(){public void onClick(DialogInterface d,int which){if(deleteMode)deleteProgram(names[which]);else loadProgram(names[which]);}}).setNegativeButton("CANCEL",null).show();}
    private void showEditorMessage(String message){new AlertDialog.Builder(this).setMessage(message).setPositiveButton("OK",null).show();}
    private void loadProgram(String name){try{FileInputStream in=openFileInput(name);StringBuilder text=new StringBuilder();byte[] buffer=new byte[4096];int n;while((n=in.read(buffer))>0)text.append(new String(buffer,0,n,"UTF-8"));in.close();editor.setText(text.toString());showEditorMessage("LOADED: "+name);}catch(Exception e){showEditorMessage("ERROR: "+e.getMessage());}}
    private void saveProgram(String name)throws Exception{FileOutputStream out=openFileOutput(name,MODE_PRIVATE);out.write(editor.getText().toString().getBytes("UTF-8"));out.close();}
    private void deleteProgram(final String name){new AlertDialog.Builder(this).setTitle("DELETE").setMessage("Delete "+name+"?").setPositiveButton("DELETE",new DialogInterface.OnClickListener(){public void onClick(DialogInterface d,int which){showEditorMessage(deleteFile(name)?"DELETED: "+name:"DELETE FAILED");}}).setNegativeButton("CANCEL",null).show();}
    private String[] getProgramNames(){String[] all=getFilesDir().list();ArrayList<String> result=new ArrayList<String>();if(all!=null)for(int i=0;i<all.length;i++)if(all[i].toLowerCase().endsWith(".bas"))result.add(all[i]);Collections.sort(result);return result.toArray(new String[result.size()]);}
    private String normalizeName(String raw){String name=raw==null?"":raw.trim();if(name.length()==0)name="PROGRAM.bas";if(!name.toLowerCase().endsWith(".bas"))name+=".bas";if(!name.matches("[A-Za-z0-9._-]+\\.bas"))return null;if(name.length()>64)return null;return name;}

    public String input(final String prompt){
        pendingInput="";final Object lock=this;
        runOnUiThread(new Runnable(){public void run(){final EditText field=new EditText(MainActivity.this);field.setSingleLine(true);new AlertDialog.Builder(MainActivity.this).setTitle("INPUT").setMessage(prompt).setView(field)
            .setPositiveButton("OK",new DialogInterface.OnClickListener(){public void onClick(DialogInterface d,int w){synchronized(lock){pendingInput=field.getText().toString();lock.notify();}}})
            .setNegativeButton("CANCEL",new DialogInterface.OnClickListener(){public void onClick(DialogInterface d,int w){synchronized(lock){pendingInput="";lock.notify();}}})
            .setOnCancelListener(new DialogInterface.OnCancelListener(){public void onCancel(DialogInterface d){synchronized(lock){lock.notify();}}}).show();}});
        synchronized(lock){try{lock.wait();}catch(InterruptedException e){Thread.currentThread().interrupt();}}
        return pendingInput;
    }
}
