package com.naivebasic;

import java.util.*;

public class BasicInterpreter {
    public interface InputProvider { String input(String prompt); }
    public interface InputStateProvider extends InputProvider {
        int getKey();
        boolean isTouch();
        int getTouchX();
        int getTouchY();
        int getScreenX();
        int getScreenY();
        int getGiro();
    }
    public interface ScreenProvider extends InputStateProvider {
        void print(String s);
        void printAt(int row, int col, String s);
        void setScreen(int mode, int charset) throws Exception;
        void beep(double duration, double pitch) throws Exception;
        void play(String[] patterns) throws Exception;
        void setInk(int color);
        void setPaper(int color);
        void tab(int count);
        void plot(int x, int y, int color);
        void draw(int dx, int dy, int color) throws Exception;
        void drawLine(int x1, int y1, int x2, int y2) throws Exception;
        void drawLineTo(int x2, int y2) throws Exception;
        void circle(int xc, int yc, int rx, int ry, boolean filled) throws Exception;
        void triangle(int x1, int y1, int x2, int y2, int x3, int y3, boolean filled) throws Exception;
        void paintArea(int x, int y) throws Exception;
    }

    private final InputProvider input;
    private final Map<String, Double> numbers = new HashMap<String, Double>();
    private final Map<String, String> strings = new HashMap<String, String>();
    private final ArrayList<String> dataValues = new ArrayList<String>();
    private int dataPointer = 0;
    private int inkColor = 7;
    private int paperColor = 0;


    private final Map<String, double[]> numArrays = new HashMap<String, double[]>();
    private final Map<String, int[]> numArrayDims = new HashMap<String, int[]>();
    private final Map<String, String[]> strArrays = new HashMap<String, String[]>();
    private final Map<String, int[]> strArrayDims = new HashMap<String, int[]>();
    private final Map<String, UserFunction> userFunctions = new HashMap<String, UserFunction>();

    private final StringBuilder out = new StringBuilder();
    private final List<Line> program = new ArrayList<Line>();
    private final Map<Integer, Integer> labels = new HashMap<Integer, Integer>();
    private final Stack<ForState> loops = new Stack<ForState>();
    private final Stack<Integer> gosubStack = new Stack<Integer>();
    private final Random random = new Random();
    private volatile boolean stopRequested = false;

    public void requestStop() {
        stopRequested = true;
    }

    public BasicInterpreter(InputProvider provider) { input = provider; }
    public BasicInterpreter() { this(null); }

    public String run(String source) {
        stopRequested = false;
        numbers.clear();
        dataValues.clear();
        dataPointer = 0; strings.clear(); out.setLength(0);
        program.clear(); labels.clear(); loops.clear(); gosubStack.clear(); userFunctions.clear();

        String[] raw = source.replace("\r", "").split("\n");
        for (int i = 0; i < raw.length; i++) {
            try {
                Line l = parseLine(raw[i], i + 1);
                if (l.text.length() > 0) {
                    if (l.number >= 0) {
                        if (labels.containsKey(Integer.valueOf(l.number)))
                            throw new Exception("Duplicate line number");
                        labels.put(Integer.valueOf(l.number), Integer.valueOf(program.size()));
                    }
                    program.add(l);
                }
            } catch (Exception e) {
                error(i + 1, message(e)); return out.toString();
            }
        }

        try {
            collectData();
        } catch (Exception e) {
            error(0, message(e));
            return out.toString();
        }

        for (int pc = 0; pc < program.size(); pc++) {
            if (stopRequested || Thread.currentThread().isInterrupted()) break;
            Line l = program.get(pc);
            String t = l.text.trim();
            String u = t.toUpperCase(Locale.US);
            try {
                if (u.length() == 0 || u.startsWith("REM") || u.startsWith("'")) continue;
                if (u.equals("END")) break;
                if (isCommand(u, "SCREEN")) screen(t.substring(6).trim());
                else if (isCommand(u, "BEEP")) beep(t.substring(4).trim());
                else if (isCommand(u, "PLAY")) play(t.substring(4).trim());
                else if (isCommand(u, "PRINT")) print(t.substring(5).trim());
                else if (isCommand(u, "DEFFN")) defineFunction(t.substring(5).trim());
                else if (isCommand(u, "DIM")) dimArray(t.substring(3).trim());
                else if (isCommand(u, "DATA")) { /* DATA is collected before execution */ }
                else if (isCommand(u, "READ")) readData(t.substring(4).trim());
                else if (isCommand(u, "RESTORE")) restoreData();
                else if (isCommand(u, "PAUSE")) doPause();
                else if (isCommand(u, "INK")) setInk(t.substring(3).trim());
                else if (isCommand(u, "PAPER")) setPaper(t.substring(5).trim());
                else if (isCommand(u, "TAB")) doTab(t.substring(3).trim());
                else if (isCommand(u, "PLOT")) plot(t.substring(4).trim());
                else if (isCommand(u, "DRAW")) draw(t.substring(4).trim());
                else if (isCommand(u, "LINE")) drawLineAbsolute(t.substring(4).trim());
                else if (isCommand(u, "PAINT")) paintArea(t.substring(5).trim());
                else if (isCommand(u, "PTRIANGLE")) triangle(t.substring(9).trim(), true);
                else if (isCommand(u, "TRIANGLE")) triangle(t.substring(8).trim(), false);
                else if (isCommand(u, "PCIRCLE")) circle(t.substring(7).trim(), true);
                else if (isCommand(u, "CIRCLE")) circle(t.substring(6).trim(), false);
                else if (isCommand(u, "INPUT")) doInput(t.substring(5).trim());
                else if (isCommand(u, "GOTO")) pc = jump(t.substring(4).trim()) - 1;
                else if (isCommand(u, "GOSUB")) { gosubStack.push(Integer.valueOf(pc)); pc = jump(t.substring(5).trim()) - 1; }
                else if (isCommand(u, "RETURN")) {
                    if (gosubStack.empty()) throw new Exception("RETURN without GOSUB");
                    pc = gosubStack.pop().intValue();
                }
                else if (isCommand(u, "IF")) {
                    Integer x = ifCommand(t);
                    if (x != null) pc = x.intValue() - 1;
                } else if (isCommand(u, "FOR")) startFor(t.substring(3).trim(), pc);
                else if (isCommand(u, "NEXT")) pc = next(t.substring(4).trim(), pc);
                else if (isCommand(u, "RANDOMIZE")) randomize(t.substring(9).trim());
                else if (isCommand(u, "LET")) assign(t.substring(3).trim());
                else if (t.indexOf('=') > 0) assign(t);
                else throw new Exception("Unknown command");
            } catch (Exception e) {
                error(l.sourceLine, message(e)); break;
            }
        }
        return out.toString();
    }

    private String message(Exception e) {
        return e.getMessage() == null ? "Syntax error" : e.getMessage();
    }

    private boolean isCommand(String upper, String command) {
        return upper.startsWith(command) &&
            (upper.length() == command.length() ||
             Character.isWhitespace(upper.charAt(command.length())));
    }

    private void beep(String text) throws Exception {
        if (!(input instanceof ScreenProvider)) throw new Exception("Sound unavailable");
        String[] a = splitTopLevel(text, ',');
        if (a.length != 2) throw new Exception("BEEP duration,pitch");
        double duration = new NumExpr(a[0]).parse();
        double pitch = new NumExpr(a[1]).parse();
        if (duration < 0) throw new Exception("Bad BEEP duration");
        ((ScreenProvider)input).beep(duration, pitch);
    }

    private void play(String text) throws Exception {
        if (!(input instanceof ScreenProvider)) throw new Exception("Sound unavailable");
        String[] parts = splitTopLevel(text, ',');
        if (parts.length < 1 || parts.length > 8) throw new Exception("Bad PLAY");
        String[] patterns = new String[parts.length];
        for (int i=0;i<parts.length;i++) patterns[i]=new ValueExpr(parts[i]).parse();
        ((ScreenProvider)input).play(patterns);
    }

    private String[] splitTopLevel(String text, char separator) throws Exception {
        ArrayList<String> r=new ArrayList<String>();
        int start=0, depth=0; boolean quote=false;
        for(int i=0;i<text.length();i++){
            char c=text.charAt(i);
            if(c=='"') quote=!quote;
            if(!quote){
                if(c=='(') depth++;
                else if(c==')') { if(depth==0) throw new Exception("Unexpected )"); depth--; }
                else if(c==separator && depth==0){
                    String part=text.substring(start,i).trim();
                    if(part.length()==0) throw new Exception("Expression expected");
                    r.add(part); start=i+1;
                }
            }
        }
        if(quote) throw new Exception("Missing quote");
        if(depth!=0) throw new Exception("Missing )");
        String last=text.substring(start).trim();
        if(last.length()==0) throw new Exception("Expression expected");
        r.add(last);
        return r.toArray(new String[r.size()]);
    }

    private void defineFunction(String text) throws Exception {
        String s = text.trim();
        int p = s.indexOf('(');
        if (p <= 0) throw new Exception("Function name expected");
        int close = s.indexOf(')', p + 1);
        if (close < 0) throw new Exception("Missing )");
        int eq = s.indexOf('=', close + 1);
        if (eq < 0) throw new Exception("= expected");

        String name = s.substring(0, p).trim().toUpperCase(Locale.US);
        String param = s.substring(p + 1, close).trim().toUpperCase(Locale.US);
        String body = s.substring(eq + 1).trim();
        if (!name.matches("[A-Z][A-Z0-9_]*")) throw new Exception("Bad function name");
        if (!param.matches("[A-Z][A-Z0-9_]*")) throw new Exception("Bad parameter");
        if (body.length() == 0) throw new Exception("Function expression expected");
        userFunctions.put(name, new UserFunction(param, body));
    }

    private void doInput(String name) throws Exception {
        name = normalizeVariable(name);
        String v = input == null ? "" : input.input(name);
        if (v == null) v = "";
        if (name.endsWith("$")) strings.put(name, v);
        else {
            try { numbers.put(name, Double.valueOf(v.trim())); }
            catch (Exception e) { throw new Exception("Number expected"); }
        }
    }

    private String normalizeVariable(String name) throws Exception {
        name = name.trim().toUpperCase(Locale.US);
        if (!name.matches("[A-Z][A-Z0-9_]*\\$?"))
            throw new Exception("Bad variable name");
        return name;
    }

    private Line parseLine(String s, int source) throws Exception {
        String t = s.trim(), rest;
        int p = 0;
        while (p < t.length() && Character.isDigit(t.charAt(p))) p++;
        if (p > 0 && (p == t.length() || Character.isWhitespace(t.charAt(p)))) {
            rest = t.substring(p).trim();
            return new Line(Integer.parseInt(t.substring(0, p)), rest, source);
        }
        return new Line(-1, t, source);
    }

    private int jump(String s) throws Exception {
        int n = (int)new NumExpr(s).parse();
        Integer pc = labels.get(Integer.valueOf(n));
        if (pc == null) throw new Exception("No such line: " + n);
        return pc.intValue();
    }

    private Integer ifCommand(String t) throws Exception {
        String body = t.substring(2).trim();
        int p = findKeyword(body, "THEN");
        if (p < 0) throw new Exception("THEN expected");
        if (!condition(body.substring(0, p).trim())) return null;

        String a = body.substring(p + 4).trim();
        String u = a.toUpperCase(Locale.US);
        if (isCommand(u, "GOTO")) return Integer.valueOf(jump(a.substring(4).trim()));
        if (a.matches("\\d+")) return Integer.valueOf(jump(a));
        executeInline(a);
        return null;
    }

    private void executeInline(String t) throws Exception {
        String u = t.toUpperCase(Locale.US);
        if (isCommand(u, "PRINT")) print(t.substring(5).trim());
        else if (isCommand(u, "LET")) assign(t.substring(3).trim());
        else if (t.indexOf('=') > 0) assign(t);
        else throw new Exception("Unsupported THEN command");
    }

    private boolean condition(String c) throws Exception {
        return new BoolExpr(c).parse();
    }

    private class BoolExpr {
        String s; int p;
        BoolExpr(String x){s=x.trim();}
        boolean parse() throws Exception { boolean v=orExpr(); skip(); if(p!=s.length()) throw new Exception("Unexpected: "+s.charAt(p)); return v; }
        boolean orExpr() throws Exception { boolean v=andExpr(); while(eatWord("OR")) v=v||andExpr(); return v; }
        boolean andExpr() throws Exception { boolean v=notExpr(); while(eatWord("AND")) v=v&&notExpr(); return v; }
        boolean notExpr() throws Exception { if(eatWord("NOT")) return !notExpr(); return atom(); }
        boolean atom() throws Exception {
            skip();
            if(eat('(')){ boolean v=orExpr(); if(!eat(')')) throw new Exception("Missing )"); return v; }
            int save=p; String left=side(); String op=operator();
            if(op==null){p=save; return new NumExpr(side()).parse()!=0;}
            String right=side();
            if(isStringExpression(left)||isStringExpression(right)){
                int q=new ValueExpr(left).parse().compareTo(new ValueExpr(right).parse());
                return op.equals("=")?q==0:op.equals("<>")?q!=0:op.equals("<")?q<0:op.equals(">")?q>0:op.equals("<=")?q<=0:q>=0;
            }
            double x=new NumExpr(left).parse(),y=new NumExpr(right).parse();
            return op.equals("=")?x==y:op.equals("<>")?x!=y:op.equals("<")?x<y:op.equals(">")?x>y:op.equals("<=")?x<=y:x>=y;
        }
        String side(){
            skip(); int a=p,d=0; boolean q=false;
            while(p<s.length()){
                char ch=s.charAt(p); if(ch=='"') q=!q;
                if(!q){ if(ch=='(')d++; else if(ch==')'&&d>0)d--; if(d==0&&(ch=='='||ch=='<'||ch=='>'||wordAt("AND")||wordAt("OR"))) break; }
                p++;
            } return s.substring(a,p).trim();
        }
        String operator(){ skip(); if(p+1<s.length()&&(s.startsWith("<>",p)||s.startsWith("<=",p)||s.startsWith(">=",p))){String x=s.substring(p,p+2);p+=2;return x;} if(p<s.length()&&(s.charAt(p)=='='||s.charAt(p)=='<'||s.charAt(p)=='>')) return String.valueOf(s.charAt(p++)); return null; }
        boolean wordAt(String w){int e=p+w.length();return e<=s.length()&&s.regionMatches(true,p,w,0,w.length())&&(p==0||!Character.isLetterOrDigit(s.charAt(p-1)))&&(e==s.length()||!Character.isLetterOrDigit(s.charAt(e)));}
        void skip(){while(p<s.length()&&Character.isWhitespace(s.charAt(p)))p++;}
        boolean eat(char x){skip();if(p<s.length()&&s.charAt(p)==x){p++;return true;}return false;}
        boolean eatWord(String w){skip();if(wordAt(w)){p+=w.length();return true;}return false;}
    }

    private boolean isStringExpression(String s) {
        return s.indexOf('"') >= 0 || s.indexOf('$') >= 0;
    }

    private void startFor(String s, int pc) throws Exception {
        int eq=s.indexOf('=');
        if(eq<0) throw new Exception("Bad FOR");
        String name=normalizeVariable(s.substring(0,eq));
        if(name.endsWith("$")) throw new Exception("FOR variable must be numeric");
        String rest=s.substring(eq+1).trim();
        int to=findKeyword(rest,"TO");
        if(to<0) throw new Exception("TO expected");
        double start=new NumExpr(rest.substring(0,to).trim()).parse();
        String after=rest.substring(to+2).trim();
        int stepPos=findKeyword(after,"STEP");
        double end,step=1;
        if(stepPos>=0) {
            end=new NumExpr(after.substring(0,stepPos).trim()).parse();
            step=new NumExpr(after.substring(stepPos+4).trim()).parse();
            if(step==0) throw new Exception("STEP cannot be zero");
        } else end=new NumExpr(after).parse();
        numbers.put(name,Double.valueOf(start));
        loops.push(new ForState(name,end,step,pc));
    }

    private int next(String s,int pc)throws Exception{
        if(loops.empty()) throw new Exception("NEXT without FOR");
        ForState f=loops.peek();
        String n=s.trim();
        if(n.length()>0 && !normalizeVariable(n).equals(f.name))
            throw new Exception("Wrong NEXT variable");
        Double old=numbers.get(f.name);
        if(old==null) throw new Exception("Undefined variable: "+f.name);
        double v=old.doubleValue()+f.step;
        numbers.put(f.name,Double.valueOf(v));
        boolean again=f.step>0?v<=f.end:v>=f.end;
        if(again) return f.pc;
        loops.pop(); return pc;
    }

    private void randomize(String s)throws Exception{
        s=s.trim();
        if(s.length()==0) random.setSeed(System.currentTimeMillis());
        else random.setSeed((long)new NumExpr(s).parse());
    }

    private void assign(String t)throws Exception{
        int p=t.indexOf('=');
        if(p<=0) throw new Exception("Assignment expected");
        String lhs=t.substring(0,p).trim();
        String v=t.substring(p+1).trim();

        int lp=lhs.indexOf('(');
        if(lp>0 && lhs.endsWith(")")){
            String n=normalizeVariable(lhs.substring(0,lp));
            String inside=lhs.substring(lp+1,lhs.length()-1);
            if(n.endsWith("$") && strArrayDims.containsKey(n)){
                strArrays.get(n)[arrayIndex(n,inside)]=new ValueExpr(v).parse();
                return;
            }
            if(!n.endsWith("$") && numArrayDims.containsKey(n)){
                numArrays.get(n)[arrayIndex(n,inside)]=Double.valueOf(new NumExpr(v).parse());
                return;
            }
        }

        String n=normalizeVariable(lhs);
        if(n.endsWith("$")) strings.put(n,new ValueExpr(v).parse());
        else numbers.put(n,Double.valueOf(new NumExpr(v).parse()));
    }

    private void print(String s)throws Exception {
        String x=s.trim();
        if(x.toUpperCase(Locale.US).startsWith("AT ")) {
            int semi=x.indexOf(';');
            if(semi<0) throw new Exception("PRINT AT expected ;");
            String pos=x.substring(2,semi).trim();
            int comma=pos.indexOf(',');
            if(comma<0) throw new Exception("PRINT AT row,col expected");
            int col=(int)new NumExpr(pos.substring(0,comma).trim()).parse();
            int row=(int)new NumExpr(pos.substring(comma+1).trim()).parse();
            String body=x.substring(semi+1).trim();

            if(input instanceof ScreenProvider) {
                ((ScreenProvider)input).printAt(row,col,"");
                printPieces(body,false);
            }
            out.append('\n');
            return;
        }

        if(input instanceof ScreenProvider) {
            printPieces(s,true);
        } else {
            out.append(new ValueExpr(s).parse()).append('\n');
        }
    }

    private void printPieces(String text, boolean newlineAtEnd)throws Exception {
        ArrayList<String> parts=new ArrayList<String>();
        ArrayList<Character> separators=new ArrayList<Character>();
        int start=0, depth=0; boolean quote=false;

        for(int i=0;i<=text.length();i++){
            char ch=i<text.length()?text.charAt(i):'\0';
            if(ch=='"') quote=!quote;
            if(!quote){
                if(ch=='(') depth++;
                else if(ch==')' && depth>0) depth--;
            }
            if(i==text.length() || (!quote && depth==0 && (ch==';'||ch==','))){
                String part=text.substring(start,i).trim();
                if(part.length()>0){
                    parts.add(part);
                    separators.add(i<text.length()?ch:';');
                }
                start=i+1;
            }
        }

        for(int i=0;i<parts.size();i++){
            String part=parts.get(i);
            String u=part.toUpperCase(Locale.US);

            if(u.startsWith("INK ")){
                setInk(part.substring(4).trim());
            } else if(u.startsWith("PAPER ")){
                setPaper(part.substring(6).trim());
            } else if(u.startsWith("TAB ")){
                doTab(part.substring(4).trim());
            } else {
                ((ScreenProvider)input).print(new ValueExpr(part).parse());
            }

            if(i<parts.size()-1 && separators.get(i)==',')
                ((ScreenProvider)input).print(" ");
        }

        if(newlineAtEnd)
            ((ScreenProvider)input).print("\n");
    }

    private void plot(String s)throws Exception {
        if(!(input instanceof ScreenProvider)) throw new Exception("Screen unavailable");
        String[] a=splitTopLevel(s, ',');
        if(a.length!=2) throw new Exception("PLOT x,y expected");
        int x=(int)new NumExpr(a[0]).parse();
        int y=(int)new NumExpr(a[1]).parse();
        int maxX=((ScreenProvider)input).getScreenX()-1;
        int maxY=((ScreenProvider)input).getScreenY()-1;
        if(x<0||x>maxX||y<0||y>maxY) throw new Exception("PLOT coordinate out of range");
        ((ScreenProvider)input).plot(x,y,inkColor);
    }

    private void draw(String s)throws Exception {
        if(!(input instanceof ScreenProvider)) throw new Exception("Screen unavailable");
        String[] a=splitTopLevel(s, ',');
        if(a.length!=2) throw new Exception("DRAW x,y expected");
        int dx=(int)new NumExpr(a[0]).parse();
        int dy=(int)new NumExpr(a[1]).parse();
        ((ScreenProvider)input).draw(dx,dy,inkColor);
    }

    private void screen(String s)throws Exception {
        if(!(input instanceof ScreenProvider)) throw new Exception("Screen unavailable");
        String x=s.trim();
        int comma=x.indexOf(',');
        int mode, charset=0;
        if(comma<0) {
            mode=(int)new NumExpr(x).parse();
        } else {
            if(x.indexOf(',',comma+1)>=0) throw new Exception("SCREEN mode,charset expected");
            mode=(int)new NumExpr(x.substring(0,comma).trim()).parse();
            charset=(int)new NumExpr(x.substring(comma+1).trim()).parse();
        }
        if(mode<0||mode>3) throw new Exception("Bad SCREEN mode");
        if(charset<0||charset>1) throw new Exception("Bad SCREEN charset");
        ((ScreenProvider)input).setScreen(mode, charset);
    }

    private int findKeyword(String s,String word){
        String u=s.toUpperCase(Locale.US); boolean quote=false;
        for(int i=0;i<=u.length()-word.length();i++){
            if(u.charAt(i)=='"') quote=!quote;
            if(quote) continue;
            if(u.regionMatches(i,word,0,word.length())){
                boolean left=i==0||Character.isWhitespace(u.charAt(i-1));
                int e=i+word.length();
                boolean right=e==u.length()||Character.isWhitespace(u.charAt(e));
                if(left&&right) return i;
            }
        } return -1;
    }

    private void error(int n,String m){ String e="ERROR "+n+": "+m+"\n"; out.append(e); if(input instanceof ScreenProvider) ((ScreenProvider)input).print(e); }
    private String fmt(double n){
        if(Double.isNaN(n)||Double.isInfinite(n)) return Double.toString(n);
        return n==Math.rint(n)?Long.toString((long)n):Double.toString(n);
    }

    private class ValueExpr {
        String s;
        ValueExpr(String x){s=x.trim();}
        String parse()throws Exception{
            StringBuilder r=new StringBuilder();
            int start=0, depth=0; boolean quote=false;
            for(int i=0;i<=s.length();i++){
                char ch=i<s.length()?s.charAt(i):'\0';
                if(ch=='"') quote=!quote;
                if(!quote){
                    if(ch=='(') depth++;
                    else if(ch==')'&&depth>0) depth--;
                }
                if(i==s.length() || (!quote&&depth==0&&(ch==';'||ch==','))){
                    String part=s.substring(start,i).trim();
                    if(part.length()==0) throw new Exception("Expression expected");
                    r.append(valuePart(part));
                    if(i<s.length()&&ch==',') r.append(' ');
                    start=i+1;
                }
            }
            if(quote) throw new Exception("Missing quote");
            return r.toString();
        }
        String valuePart(String part)throws Exception{
            // String-producing functions are evaluated as strings.
            if(hasStringFunction(part)) return stringFunction(part);

            // String-array element references must be recognized before NumExpr:
            // otherwise NumExpr interprets S$(...) as an unknown function S$.
            String uqPart=part.toUpperCase(Locale.US).trim();
            int arrayLp=uqPart.indexOf('(');
            if(arrayLp>0 && uqPart.endsWith(")")){
                String arrayName=uqPart.substring(0,arrayLp).trim();
                if(arrayName.endsWith("$") && strArrayDims.containsKey(arrayName)){
                    return getStrArray(arrayName,uqPart.substring(arrayLp+1,uqPart.length()-1));
                }
            }

            // Try the whole part as a numeric expression first. This is important
            // for numeric string functions such as VAL("123")+1 and LEN("ABC")+1.
            try { return fmt(new NumExpr(part).parse()); }
            catch(Exception ignored) { }
            StringBuilder r=new StringBuilder();
            int start=0; boolean quote=false; int depth=0;
            for(int i=0;i<=part.length();i++){
                char ch=i<part.length()?part.charAt(i):'\0';
                if(ch=='"') quote=!quote;
                if(!quote){ if(ch=='(')depth++; else if(ch==')'&&depth>0)depth--; }
                if(i==part.length()||(!quote&&depth==0&&ch=='+')){
                    String q=part.substring(start,i).trim();
                    if(q.length()==0) throw new Exception("Expression expected");
                    if(q.startsWith("\"")&&q.endsWith("\"")&&q.length()>=2) r.append(q.substring(1,q.length()-1));
                    else if(hasStringFunction(q)) r.append(stringFunction(q));
                    else if(q.toUpperCase(Locale.US).endsWith("$")){
                        String uq=q.toUpperCase(Locale.US);
                        int lp=uq.indexOf('(');
                        if(lp>0 && uq.endsWith(")")){
                            String n=normalizeVariable(q.substring(0,lp));
                            if(strArrayDims.containsKey(n)){
                                r.append(getStrArray(n,q.substring(lp+1,q.length()-1)));
                                start=i+1;
                                continue;
                            }
                        }
                        String n=normalizeVariable(q),v=strings.get(n);
                        if(v==null) throw new Exception("Undefined string: "+n);
                        r.append(v);
                    } else r.append(fmt(new NumExpr(q).parse()));
                    start=i+1;
                }
            }
            if(quote) throw new Exception("Missing quote");
            return r.toString();
        }
    }

    private double inputNumber(String name) throws Exception {
        if (!(input instanceof InputStateProvider))
            throw new Exception("Input unavailable");
        InputStateProvider p = (InputStateProvider) input;
        if (name.equals("KEY")) return p.getKey();
        if (name.equals("TOUCH")) return p.isTouch() ? 1 : 0;
        if (name.equals("TOUCHX")) return p.getTouchX();
        if (name.equals("TOUCHY")) return p.getTouchY();
        if (name.equals("SCREENX")) return p.getScreenX();
        if (name.equals("SCREENY")) return p.getScreenY();
        if (name.equals("GIRO")) return p.getGiro();
        throw new Exception("Unknown input value");
    }


    private int[] parseDims(String spec) throws Exception {
        int lp = spec.indexOf('(');
        int rp = spec.lastIndexOf(')');
        if (lp <= 0 || rp != spec.length()-1) throw new Exception("Bad DIM");
        String inside = spec.substring(lp+1, rp);
        String[] parts = inside.split(",");
        if (parts.length < 1 || parts.length > 2) throw new Exception("Bad DIM");
        int[] d = new int[parts.length];
        for (int i=0;i<parts.length;i++) {
            d[i] = (int)Math.round(new NumExpr(parts[i].trim()).parse());
            if (d[i] < 0) throw new Exception("Bad DIM");
        }
        return d;
    }

    private void dimArray(String spec) throws Exception {
        spec = spec.trim();
        int lp = spec.indexOf('(');
        if (lp <= 0) throw new Exception("Bad DIM");
        String name = normalizeVariable(spec.substring(0, lp).trim());
        int[] d = parseDims(spec);

        if (name.endsWith("$")) {
            int size = d.length == 1 ? d[0]+1 : (d[0]+1)*(d[1]+1);
            strArrays.put(name, new String[size]);
            strArrayDims.put(name, d);
        } else {
            int size = d.length == 1 ? d[0]+1 : (d[0]+1)*(d[1]+1);
            numArrays.put(name, new double[size]);
            numArrayDims.put(name, d);
        }
    }

    private int arrayIndex(String name, String inside) throws Exception {
        int[] d = name.endsWith("$") ? strArrayDims.get(name) : numArrayDims.get(name);
        if (d == null) throw new Exception("Undefined array: " + name);
        String[] ix = inside.split(",");
        if (ix.length != d.length) throw new Exception("Bad array index");
        int a = (int)Math.round(new NumExpr(ix[0].trim()).parse());
        if (a < 0 || a > d[0]) throw new Exception("Array index");
        if (d.length == 1) return a;
        int b = (int)Math.round(new NumExpr(ix[1].trim()).parse());
        if (b < 0 || b > d[1]) throw new Exception("Array index");
        return a * (d[1]+1) + b;
    }

    private double getNumArray(String name, String inside) throws Exception {
        double[] a = numArrays.get(name);
        if (a == null) throw new Exception("Undefined array: " + name);
        return a[arrayIndex(name, inside)];
    }

    private String getStrArray(String name, String inside) throws Exception {
        String[] a = strArrays.get(name);
        if (a == null) throw new Exception("Undefined array: " + name);
        String v = a[arrayIndex(name, inside)];
        return v == null ? "" : v;
    }


    private void collectData() throws Exception {
        dataValues.clear();
        dataPointer = 0;
        for (Line ln : program) {
            String t = ln.text.trim();
            if (t.regionMatches(true, 0, "DATA", 0, 4) &&
                (t.length() == 4 || Character.isWhitespace(t.charAt(4)))) {
                String body = t.substring(4).trim();
                if (!body.isEmpty()) {
                    for (String item : splitDataItems(body)) {
                        dataValues.add(item.trim());
                    }
                }
            }
        }
    }

    private ArrayList<String> splitDataItems(String body) {
        ArrayList<String> out = new ArrayList<String>();
        StringBuilder cur = new StringBuilder();
        boolean quoted = false;
        for (int i=0;i<body.length();i++) {
            char c=body.charAt(i);
            if(c=='"') quoted=!quoted;
            if(c==',' && !quoted){
                out.add(stripDataQuotes(cur.toString().trim()));
                cur.setLength(0);
            } else cur.append(c);
        }
        if(cur.length()>0) out.add(stripDataQuotes(cur.toString().trim()));
        return out;
    }

    private String stripDataQuotes(String x) {
        if(x.length()>=2 && x.charAt(0)=='"' && x.charAt(x.length()-1)=='"')
            return x.substring(1,x.length()-1);
        return x;
    }

    private void readData(String vars) throws Exception {
        String[] names=vars.split(",");
        for(String raw:names){
            String n=normalizeVariable(raw.trim());
            if(dataPointer>=dataValues.size()) throw new Exception("Out of DATA");
            String value=dataValues.get(dataPointer++);
            if(n.endsWith("$")) strings.put(n,value);
            else numbers.put(n,Double.valueOf(new NumExpr(value).parse()));
        }
    }

    private void restoreData() {
        dataPointer=0;
    }


    private int clampColor(int c) {
        return c < 0 ? 0 : (c > 255 ? 255 : c);
    }

    private void setInk(String arg) throws Exception {
        inkColor = clampColor((int)Math.round(new NumExpr(arg).parse()));
        if (input instanceof ScreenProvider)
            ((ScreenProvider)input).setInk(inkColor);
    }

    private void setPaper(String arg) throws Exception {
        paperColor = clampColor((int)Math.round(new NumExpr(arg).parse()));
        if (input instanceof ScreenProvider)
            ((ScreenProvider)input).setPaper(paperColor);
    }

    private void doTab(String arg) throws Exception {
        int n = (int)Math.round(new NumExpr(arg).parse());
        if (n < 0) n = 0;
        if (input instanceof ScreenProvider)
            ((ScreenProvider)input).tab(n);
    }

    private void doPause() throws Exception {
        if (input instanceof InputStateProvider) {
            InputStateProvider p = (InputStateProvider)input;
            while (p.getKey() != 0 || p.isTouch()) Thread.sleep(20);
            while (p.getKey() == 0 && !p.isTouch()) Thread.sleep(20);
        }
    }


    private void drawLineAbsolute(String arg) throws Exception {
        String[] a = arg.split(",");
        if(a.length != 2 && a.length != 4) throw new Exception("LINE x2,y2 or LINE x1,y1,x2,y2 expected");
        if(!(input instanceof ScreenProvider)) return;
        ScreenProvider p = (ScreenProvider)input;
        if(a.length == 2){
            int x2=(int)Math.round(new NumExpr(a[0].trim()).parse());
            int y2=(int)Math.round(new NumExpr(a[1].trim()).parse());
            p.drawLineTo(x2,y2);
        } else {
            int x1=(int)Math.round(new NumExpr(a[0].trim()).parse());
            int y1=(int)Math.round(new NumExpr(a[1].trim()).parse());
            int x2=(int)Math.round(new NumExpr(a[2].trim()).parse());
            int y2=(int)Math.round(new NumExpr(a[3].trim()).parse());
            p.drawLine(x1,y1,x2,y2);
        }
    }

    private void circle(String arg, boolean filled) throws Exception {
        if(!(input instanceof ScreenProvider)) throw new Exception("Screen unavailable");
        String[] a = arg.split(",");
        if(a.length != 3 && a.length != 4)
            throw new Exception((filled ? "PCIRCLE" : "CIRCLE") + " xc,yc,r or xc,yc,rx,ry expected");
        int xc=(int)Math.round(new NumExpr(a[0].trim()).parse());
        int yc=(int)Math.round(new NumExpr(a[1].trim()).parse());
        int rx=(int)Math.round(new NumExpr(a[2].trim()).parse());
        int ry=(a.length==3) ? rx : (int)Math.round(new NumExpr(a[3].trim()).parse());
        if(rx<0) rx=-rx;
        if(ry<0) ry=-ry;
        ((ScreenProvider)input).circle(xc,yc,rx,ry,filled);
    }

    private void paintArea(String arg) throws Exception {
        if(!(input instanceof ScreenProvider)) throw new Exception("Screen unavailable");
        String[] a=arg.split(",");
        if(a.length!=2) throw new Exception("PAINT x,y expected");
        int x=(int)Math.round(new NumExpr(a[0].trim()).parse());
        int y=(int)Math.round(new NumExpr(a[1].trim()).parse());
        int maxX=((ScreenProvider)input).getScreenX()-1, maxY=((ScreenProvider)input).getScreenY()-1;
        if(x<0||x>maxX||y<0||y>maxY) throw new Exception("PAINT coordinate out of range");
        ((ScreenProvider)input).paintArea(x,y);
    }

    private void triangle(String arg, boolean filled) throws Exception {
        if(!(input instanceof ScreenProvider)) throw new Exception("Screen unavailable");
        String[] a = arg.split(",");
        if(a.length != 6) throw new Exception((filled ? "PTRIANGLE" : "TRIANGLE") + " x1,y1,x2,y2,x3,y3 expected");
        int x1=(int)Math.round(new NumExpr(a[0].trim()).parse());
        int y1=(int)Math.round(new NumExpr(a[1].trim()).parse());
        int x2=(int)Math.round(new NumExpr(a[2].trim()).parse());
        int y2=(int)Math.round(new NumExpr(a[3].trim()).parse());
        int x3=(int)Math.round(new NumExpr(a[4].trim()).parse());
        int y3=(int)Math.round(new NumExpr(a[5].trim()).parse());
        ((ScreenProvider)input).triangle(x1,y1,x2,y2,x3,y3,filled);
    }

    private class NumExpr {
        String s; int p;
        NumExpr(String x){s=x.trim();}

        double parse()throws Exception{
            double v=add(); skip();
            if(p!=s.length()) throw new Exception("Unexpected: "+s.charAt(p));
            return v;
        }
        double add()throws Exception{
            double v=mul();
            while(true){skip(); if(eat('+'))v+=mul(); else if(eat('-'))v-=mul(); else return v;}
        }
        double mul()throws Exception{
            double v=power();
            while(true){
                skip();
                if(eat('*'))v*=power();
                else if(eat('/')){double d=power();if(d==0)throw new Exception("Division by zero");v/=d;}
                else if(eatWord("MOD")){
                    double d=power();
                    if(d==0) throw new Exception("Division by zero");
                    v=v-Math.floor(v/d)*d;
                }
                else if(eat('%')){
                    double d=power();
                    if(d==0) throw new Exception("Division by zero");
                    v=v-Math.floor(v/d)*d;
                }
                else return v;
            }
        }
        // Right-associative exponentiation: 2^3^2 = 2^(3^2).
        double power()throws Exception{
            double v=unary(); skip();
            if(eat('^')){
                double e=power();
                v=Math.pow(v,e);
                if(Double.isNaN(v)||Double.isInfinite(v)) throw new Exception("Math domain error");
            }
            return v;
        }
        double unary()throws Exception{
            skip(); if(eat('+'))return unary(); if(eat('-'))return -unary(); return factor();
        }
        double factor()throws Exception{
            skip();
            if(eat('(')){double v=add();if(!eat(')'))throw new Exception("Missing )");return v;}

            if(p<s.length()&&(Character.isDigit(s.charAt(p))||s.charAt(p)=='.')){
                int a=p++;
                while(p<s.length()&&(Character.isDigit(s.charAt(p))||s.charAt(p)=='.'))p++;
                try{return Double.parseDouble(s.substring(a,p));}
                catch(Exception e){throw new Exception("Bad number");}
            }

            if(p<s.length()&&Character.isLetter(s.charAt(p))){
                int a=p++;
                while(p<s.length()&&(Character.isLetterOrDigit(s.charAt(p))||s.charAt(p)=='_'))p++;
                if(p<s.length() && s.charAt(p)=='$') p++;
                String n=s.substring(a,p).toUpperCase(Locale.US);
                if(n.equals("FN")){
                    skip();
                    if(p>=s.length() || !Character.isLetter(s.charAt(p))) throw new Exception("Function name expected");
                    int fa=p++;
                    while(p<s.length() && (Character.isLetterOrDigit(s.charAt(p)) || s.charAt(p)=='_')) p++;
                    String fn=s.substring(fa,p).toUpperCase(Locale.US);
                    if(!userFunctions.containsKey(fn)) throw new Exception("Unknown function: "+fn);
                    skip();
                    if(!eat('(')) throw new Exception("Missing (");
                    String argText=readArgumentText();
                    double arg=new NumExpr(argText).parse();
                    return callUserFunction(fn,arg);
                }
                if(p<s.length() && s.charAt(p)=='(' && numArrayDims.containsKey(n)){
                    int start = ++p, depth = 1;
                    while(p<s.length() && depth>0){
                        if(s.charAt(p)=='(') depth++;
                        else if(s.charAt(p)==')') depth--;
                        p++;
                    }
                    if(depth!=0) throw new Exception("Missing )");
                    return getNumArray(n, s.substring(start,p-1));
                }

                if(n.equals("PI")) return Math.PI;
                if(n.equals("SCREENY")) return inputNumber("SCREENY");
                if(n.equals("SCREENX")) return inputNumber("SCREENX");
                if(n.equals("GIRO")) return inputNumber("GIRO");
                if(n.equals("TOUCHY")) return inputNumber("TOUCHY");
                if(n.equals("TOUCHX")) return inputNumber("TOUCHX");
                if(n.equals("TOUCH")) return inputNumber("TOUCH");
                if(n.equals("KEY")) return inputNumber("KEY");
                if(n.equals("RND")) return random.nextDouble();

                skip();
                if(n.equals("INKEY$")) throw new Exception("String expression expected");
                if(eat('(')){
                    if(userFunctions.containsKey(n)) {
                        String argText = readArgumentText();
                        double arg = new NumExpr(argText).parse();
                        return callUserFunction(n, arg);
                    }
                    if(n.equals("CODE") || n.equals("LEN") || n.equals("VAL")){
                        String argText = readArgumentText();
                        String value = new ValueExpr(argText).parse();
                        if(n.equals("CODE")) return value.length() == 0 ? 0 : value.charAt(0);
                        if(n.equals("LEN")) return value.length();
                        try { return Double.parseDouble(value.trim()); }
                        catch(Exception ex) { return 0; }
                    }
                    if(n.equals("CHR$") || n.equals("STR$"))
                        throw new Exception("String expression expected");
                    double arg=add();
                    if(n.equals("MOD")){
                        if(!eat(',')) throw new Exception("Comma expected");
                        double arg2=add();
                        if(!eat(')')) throw new Exception("Missing )");
                        if(arg2==0) throw new Exception("Division by zero");
                        return arg-Math.floor(arg/arg2)*arg2;
                    }
                    if(!eat(')')) throw new Exception("Missing )");
                    return function(n,arg);
                }

                Double v=numbers.get(n);
                if(v==null) throw new Exception("Undefined variable: "+n);
                return v.doubleValue();
            }
            throw new Exception("Number expected");
        }

        String readArgumentText() throws Exception {
            int start = p;
            int depth = 0;
            boolean quote = false;
            while(p < s.length()){
                char c = s.charAt(p++);
                if(c == '"') quote = !quote;
                if(!quote){
                    if(c == '(') depth++;
                    else if(c == ')'){
                        if(depth == 0) return s.substring(start, p - 1);
                        depth--;
                    }
                }
            }
            throw new Exception("Missing )");
        }

        double callUserFunction(String n, double arg) throws Exception {
            UserFunction f = userFunctions.get(n);
            if (f == null) throw new Exception("Unknown function: " + n);
            Double old = numbers.get(f.param);
            boolean had = numbers.containsKey(f.param);
            numbers.put(f.param, Double.valueOf(arg));
            try {
                return new NumExpr(f.body).parse();
            } finally {
                if (had) numbers.put(f.param, old);
                else numbers.remove(f.param);
            }
        }

        double function(String n,double x)throws Exception{
            if(n.equals("SIN")) return Math.sin(x);
            if(n.equals("COS")) return Math.cos(x);
            if(n.equals("TAN")) return Math.tan(x);
            if(n.equals("COT")){
                double y=Math.tan(x);
                if(Math.abs(y)<1e-15) throw new Exception("Division by zero");
                return 1.0/y;
            }
            if(n.equals("ASN")){
                if(x<-1||x>1) throw new Exception("Math domain error");
                return Math.asin(x);
            }
            if(n.equals("ACS")){
                if(x<-1||x>1) throw new Exception("Math domain error");
                return Math.acos(x);
            }
            if(n.equals("ATN")) return Math.atan(x);
            if(n.equals("EXP")){
                double y=Math.exp(x);
                if(Double.isInfinite(y)) throw new Exception("Math domain error");
                return y;
            }
            if(n.equals("LN")){
                if(x<=0) throw new Exception("Math domain error");
                return Math.log(x);
            }
            if(n.equals("SQR")){
                if(x<0) throw new Exception("Math domain error");
                return Math.sqrt(x);
            }
            if(n.equals("ABS")) return Math.abs(x);
            if(n.equals("INT")) return Math.floor(x);
            if(n.equals("SGN")) return x>0?1:x<0?-1:0;
            throw new Exception("Unknown function: "+n);
        }

        void skip(){while(p<s.length()&&Character.isWhitespace(s.charAt(p)))p++;}
        boolean eatWord(String word){
            skip();
            int e=p+word.length();
            if(e<=s.length() && s.regionMatches(true,p,word,0,word.length()) &&
                    (p==0 || !Character.isLetterOrDigit(s.charAt(p-1))) &&
                    (e==s.length() || !Character.isLetterOrDigit(s.charAt(e)))){
                p=e; return true;
            }
            return false;
        }
        boolean eat(char c){skip();if(p<s.length()&&s.charAt(p)==c){p++;return true;}return false;}
    }

    private static class Line {
        int number; String text; int sourceLine;
        Line(int n,String t,int s){number=n;text=t;sourceLine=s;}
    }
    private static class ForState {
        String name; double end,step; int pc;
        ForState(String n,double e,double st,int p){name=n;end=e;step=st;pc=p;}
    }
    private static class UserFunction {
        String param; String body;
        UserFunction(String p, String b){param=p;body=b;}
    }

    private String stringFunction(String expr) throws Exception {
        String e = expr.trim();
        String u = e.toUpperCase(Locale.US);

        if (u.startsWith("CHR$(") && e.endsWith(")")) {
            double n = new NumExpr(e.substring(5, e.length() - 1)).parse();
            return String.valueOf((char)(((int)Math.round(n)) & 255));
        }
        if (u.startsWith("STR$(") && e.endsWith(")")) {
            double n = new NumExpr(e.substring(5, e.length() - 1)).parse();
            if (n == Math.rint(n)) return Long.toString((long)n);
            return Double.toString(n);
        }
        if (u.equals("INKEY$")) {
            int k = (int)inputNumber("KEY");
            return k == 0 ? "" : String.valueOf((char)(k & 255));
        }
        if (e.length() >= 2 && e.charAt(0) == '"' && e.charAt(e.length() - 1) == '"') {
            return e.substring(1, e.length() - 1);
        }
        if (e.toUpperCase(Locale.US).endsWith("$")) {
            String n = normalizeVariable(e);
            String v = strings.get(n);
            if (v == null) throw new Exception("Undefined string: " + n);
            return v;
        }
        return e;
    }

    private boolean hasStringFunction(String expr) {
        String u = expr.trim().toUpperCase(Locale.US);
        return u.startsWith("CHR$(") || u.startsWith("STR$(") || u.equals("INKEY$");
    }


}
