package com.naivebasic;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Color;
import android.util.AttributeSet;
import android.view.View;

public class BasicScreenView extends View {
    private final Paint paint = new Paint();
    // BASIC always renders into a fixed logical viewport; Android only scales that viewport.
    private int viewportW(){ return (mode==1||mode==3)?240:320; }
    private int viewportH(){ return (mode==1||mode==3)?320:240; }
    // The BASIC viewport is logical, but on larger Android displays it fills the
    // complete available surface. At the native 320x240/240x320 size the scale
    // remains uniform, so the original pixel geometry is not distorted.
    private float scaleX(){ return getWidth()/(float)viewportW(); }
    private float scaleY(){ return getHeight()/(float)viewportH(); }
    private float viewportLeft(){ return 0f; }
    private float viewportTop(){ return 0f; }
    private final byte[][] chars = new byte[40][80];
    private final byte[][] fg = new byte[40][80];
    private final byte[][] bg = new byte[40][80];
    private int mode=0, cols=40, rows=30, cellW=8, cellH=8, cursorX=0, cursorY=0;
    private final short[] pixels = new short[320*320];
    private int plotX=0, plotY=0;
    private boolean compact=false;
private int inkColor=7, paperColor=0;
    private boolean hasOutput=false;

    public BasicScreenView(Context c, AttributeSet a){super(c,a);paint.setAntiAlias(false);resetScreen();}
    public BasicScreenView(Context c){this(c,null);}

    public void resetScreen(){setScreenMode(0);clear();}
    public void setScreenMode(int m){setScreenMode(m,compact);}
    public void setScreenMode(int m, boolean c){mode=m;compact=c;updateGrid();cursorX=0;cursorY=0;clear();}
    private void updateGrid(){ if(mode==1||mode==3){cols=compact?60:30;rows=40;}else{cols=compact?80:40;rows=30;} cellW=compact?4:8; cellH=8; }
    public void setCompact(boolean on){compact=on; updateGrid(); cursorX=0; cursorY=0; clear();}
    private synchronized void clear(){
        for(int y=0;y<40;y++)for(int x=0;x<80;x++){chars[y][x]=32;fg[y][x]=(byte)inkColor;bg[y][x]=(byte)paperColor;}
        java.util.Arrays.fill(pixels,(short)-1);
        plotX=0; plotY=0;
        hasOutput=false;invalidate();
    }

    public synchronized void plotPoint(int x,int y,int color){
        if(x<0||x>=viewportW()||y<0||y>=viewportH()) return;
        pixels[y*320+x]=(short)clamp(color);
        plotX=x; plotY=y;
        postInvalidate();
    }

    public synchronized void draw(int dx,int dy,int color) throws Exception {
        int x0=plotX, y0=plotY;
        int x1=x0+dx, y1=y0+dy;
        if(x1<0||x1>=viewportW()||y1<0||y1>=viewportH())
            throw new Exception("DRAW coordinate out of range");
        int sx=x0<x1?1:-1, sy=y0<y1?1:-1;
        int adx=Math.abs(x1-x0), ady=Math.abs(y1-y0);
        int err=adx-ady;
        while(true){
            pixels[y0*320+x0]=(short)clamp(color);
            if(x0==x1 && y0==y1) break;
            int e2=2*err;
            if(e2>-ady){ err-=ady; x0+=sx; }
            if(e2<adx){ err+=adx; y0+=sy; }
        }
        plotX=x1; plotY=y1;
        postInvalidate();
    }

    public boolean hasOutput(String s){return hasOutput && s!=null && s.length()>0;}
    public int logicalX(int px){float sx=scaleX();return clamp((int)((px-viewportLeft())/sx),0,viewportW()-1);}
    public int logicalY(int py){float sy=scaleY();return clamp((int)((py-viewportTop())/sy),0,viewportH()-1);}
    private int clamp(int v,int a,int b){return v<a?a:v>b?b:v;}

    public void printAt(int row,int col,String s){cursorY=clamp(row,0,rows-1);cursorX=clamp(col,0,cols-1);printText(s);}
    public void printText(String s){
        if(s==null)return;hasOutput=true;
        String[] parts=s.replace("\r","").split("\n",-1);
        for(int p=0;p<parts.length;p++){
            String line=parts[p];
            for(int i=0;i<line.length();i++){
                char ch=line.charAt(i);
                if(ch=='\t'){cursorX=(cursorX+4)&~3; if(cursorX>=cols){newline();} continue;}
                put((byte)encode(ch));
            }
            if(p<parts.length-1)newline();
        }
        invalidate();
    }
    private void put(byte b){
        chars[cursorY][cursorX]=b;
        fg[cursorY][cursorX]=(byte)inkColor;
        bg[cursorY][cursorX]=(byte)paperColor;
        cursorX++;if(cursorX>=cols)newline();
    }
    private void newline(){cursorX=0;cursorY++;if(cursorY>=rows){for(int y=1;y<rows;y++)System.arraycopy(chars[y],0,chars[y-1],0,cols);for(int x=0;x<cols;x++){chars[rows-1][x]=32;fg[rows-1][x]=(byte)inkColor;bg[rows-1][x]=(byte)paperColor;}cursorY=rows-1;}}

    private int encode(char c){
        if(c<256)return c;
        // KOI8-R-compatible Cyrillic mapping for common Russian letters.
        switch(c){case 'А':return 0xE1;case 'Б':return 0xE2;case 'В':return 0xF7;case 'Г':return 0xE7;case 'Д':return 0xE4;case 'Е':return 0xE5;case 'Ё':return 0xB3;case 'Ж':return 0xF6;case 'З':return 0xFA;case 'И':return 0xE9;case 'Й':return 0xEA;case 'К':return 0xEB;case 'Л':return 0xEC;case 'М':return 0xED;case 'Н':return 0xEE;case 'О':return 0xEF;case 'П':return 0xF0;case 'Р':return 0xF2;case 'С':return 0xF3;case 'Т':return 0xF4;case 'У':return 0xF5;case 'Ф':return 0xE6;case 'Х':return 0xE8;case 'Ц':return 0xE3;case 'Ч':return 0xFE;case 'Ш':return 0xFB;case 'Щ':return 0xFD;case 'Ъ':return 0xFF;case 'Ы':return 0xF9;case 'Ь':return 0xF8;case 'Э':return 0xFC;case 'Ю':return 0xE0;case 'Я':return 0xF1;
        case 'а':return 0xC1;case 'б':return 0xC2;case 'в':return 0xD7;case 'г':return 0xC7;case 'д':return 0xC4;case 'е':return 0xC5;case 'ё':return 0xA3;case 'ж':return 0xD6;case 'з':return 0xDA;case 'и':return 0xC9;case 'й':return 0xCA;case 'к':return 0xCB;case 'л':return 0xCC;case 'м':return 0xCD;case 'н':return 0xCE;case 'о':return 0xCF;case 'п':return 0xD0;case 'р':return 0xD2;case 'с':return 0xD3;case 'т':return 0xD4;case 'у':return 0xD5;case 'ф':return 0xC6;case 'х':return 0xC8;case 'ц':return 0xC3;case 'ч':return 0xDE;case 'ш':return 0xDB;case 'щ':return 0xDD;case 'ъ':return 0xDF;case 'ы':return 0xD9;case 'ь':return 0xD8;case 'э':return 0xDC;case 'ю':return 0xC0;case 'я':return 0xD1;default:return '?';}
    }

    
    public void setInkColor(int c){ inkColor = clamp(c); invalidate(); }
    public void setPaperColor(int c){ paperColor = clamp(c); invalidate(); }
    public void tab(int n){ cursorX += n; while(cursorX >= cols) newline(); invalidate(); }
    private int clamp(int c){ return c<0?0:(c>255?255:c); }

    public synchronized void drawLine(int x1,int y1,int x2,int y2){
        drawLineInternal(x1,y1,x2,y2);
    }

    public synchronized void drawLineTo(int x2,int y2){
        drawLineInternal(plotX,plotY,x2,y2);
    }

    public synchronized void circle(int xc,int yc,int rx,int ry,boolean filled){
        if(rx<0) rx=-rx;
        if(ry<0) ry=-ry;
        if(filled){
            if(rx==0 || ry==0){
                if(rx==0 && ry==0){
                    setPixel(xc,yc);
                } else if(rx==0){
                    for(int y=yc-ry;y<=yc+ry;y++) setPixel(xc,y);
                } else {
                    for(int x=xc-rx;x<=xc+rx;x++) setPixel(x,yc);
                }
            } else {
                for(int dy=-ry;dy<=ry;dy++){
                    double q=1.0-((double)dy*dy)/((double)ry*ry);
                    if(q<0) continue;
                    int span=(int)Math.round(rx*Math.sqrt(q));
                    for(int x=xc-span;x<=xc+span;x++) setPixel(x,yc+dy);
                }
            }
        } else {
            if(rx==0 && ry==0){
                setPixel(xc,yc);
            } else if(rx==0){
                for(int y=yc-ry;y<=yc+ry;y++) setPixel(xc,y);
            } else if(ry==0){
                for(int x=xc-rx;x<=xc+rx;x++) setPixel(x,yc);
            } else {
                for(int dx=-rx;dx<=rx;dx++){
                    double q=1.0-((double)dx*dx)/((double)rx*rx);
                    if(q<0) continue;
                    int dy=(int)Math.round(ry*Math.sqrt(q));
                    setPixel(xc+dx,yc+dy);
                    setPixel(xc+dx,yc-dy);
                }
                for(int dy=-ry;dy<=ry;dy++){
                    double q=1.0-((double)dy*dy)/((double)ry*ry);
                    if(q<0) continue;
                    int dx=(int)Math.round(rx*Math.sqrt(q));
                    setPixel(xc+dx,yc+dy);
                    setPixel(xc-dx,yc+dy);
                }
            }
        }
        postInvalidate();
    }

    public synchronized void triangle(int x1,int y1,int x2,int y2,int x3,int y3,boolean filled){
        if(!filled){
            drawLineInternal(x1,y1,x2,y2);
            drawLineInternal(x2,y2,x3,y3);
            drawLineInternal(x3,y3,x1,y1);
        } else {
            // Scanline fill. Pixels outside the logical screen are simply clipped.
            int minY=Math.min(y1,Math.min(y2,y3));
            int maxY=Math.max(y1,Math.max(y2,y3));
            for(int y=minY;y<=maxY;y++){
                int[] xs=new int[3]; int count=0;
                count=addTriangleIntersection(xs,count,x1,y1,x2,y2,y);
                count=addTriangleIntersection(xs,count,x2,y2,x3,y3,y);
                count=addTriangleIntersection(xs,count,x3,y3,x1,y1,y);
                if(count>=2){
                    if(xs[0]>xs[1]){int t=xs[0];xs[0]=xs[1];xs[1]=t;}
                    if(count==3 && xs[1]>xs[2]){int t=xs[1];xs[1]=xs[2];xs[2]=t;}
                    if(count==3 && xs[0]>xs[1]){int t=xs[0];xs[0]=xs[1];xs[1]=t;}
                    int left=xs[0], right=xs[count-1];
                    for(int x=left;x<=right;x++) setPixel(x,y);
                }
            }
        }
        plotX=x3; plotY=y3;
        postInvalidate();
    }

    private int addTriangleIntersection(int[] xs,int count,int x1,int y1,int x2,int y2,int y){
        if(y1==y2) return count;
        int ymin=Math.min(y1,y2), ymax=Math.max(y1,y2);
        if(y<ymin || y>=ymax) return count;
        int x=(int)Math.round(x1+(double)(y-y1)*(x2-x1)/(double)(y2-y1));
        if(count<xs.length) xs[count++]=x;
        return count;
    }

    private void setPixel(int x,int y){
        if(x>=0 && x<viewportW() && y>=0 && y<viewportH())
            pixels[y*320+x]=(short)clamp(inkColor);
    }

    private void drawLineInternal(int x1,int y1,int x2,int y2){
        if(x1<0||x1>=viewportW()||y1<0||y1>=viewportH()||x2<0||x2>=viewportW()||y2<0||y2>=viewportH())
            return;
        int dx=Math.abs(x2-x1), sx=x1<x2?1:-1;
        int dy=-Math.abs(y2-y1), sy=y1<y2?1:-1;
        int err=dx+dy;
        while(true){
            pixels[y1*320+x1]=(short)clamp(inkColor);
            if(x1==x2 && y1==y2) break;
            int e2=2*err;
            if(e2>=dy){err+=dy; x1+=sx;}
            if(e2<=dx){err+=dx; y1+=sy;}
        }
        plotX=x2; plotY=y2;
        postInvalidate();
    }

protected void onDraw(Canvas c){
        super.onDraw(c);
        float sx=scaleX(),sy=scaleY();
        float ox=viewportLeft(),oy=viewportTop();
        c.drawColor(palette(bg[0][0]&255));
        // Draw text first. A blank text cell must not cover the graphics layer.
        // This is important because the text grid is always present over the whole
        // screen, while PLOT stores points in a separate logical pixel buffer.
        for(int y=0;y<rows;y++)for(int x=0;x<cols;x++){
            float px=ox+x*cellW*sx, py=oy+y*8*sy;
            paint.setColor(palette(bg[y][x]&255));
            paint.setStyle(Paint.Style.FILL);
            c.drawRect(px,py,px+cellW*sx,py+8*sy,paint);
            drawGlyph(c,chars[y][x]&255,px,py,sx,sy,palette(fg[y][x]&255));
        }
        // Draw PLOT points last so they remain visible even on blank text cells.
        synchronized(this){
            for(int y=0;y<viewportH();y++)for(int x=0;x<viewportW();x++){
                int pc=pixels[y*320+x];
                if(pc>=0){
                    paint.setColor(palette(pc&255));
                    paint.setStyle(Paint.Style.FILL);
                    float px=ox+x*sx, py=oy+y*sy;
                    c.drawRect(px,py,px+sx,py+sy,paint);
                }
            }
        }
    }

    private int palette(int index){
        // 256-color EGA-style logical palette:
        // 0..15 standard colors, 16..255 extended RGB cube/greys.
        if(index<16){
            final int[] p={Color.BLACK,Color.BLUE,Color.GREEN,Color.CYAN,
                Color.RED,Color.MAGENTA,Color.YELLOW,Color.WHITE,
                Color.rgb(64,64,64),Color.rgb(64,64,255),Color.rgb(64,255,64),
                Color.rgb(64,255,255),Color.rgb(255,64,64),Color.rgb(255,64,255),
                Color.rgb(255,255,64),Color.rgb(255,255,255)};
            return p[index];
        }
        int n=index-16;
        if(n>=216) {
            int g=8+(n-216)*10;
            if(g>255)g=255;
            return Color.rgb(g,g,g);
        }
        int r=(n/36)*51, g=((n/6)%6)*51, b=(n%6)*51;
        return Color.rgb(r,g,b);
    }

    private void drawGlyph(Canvas c,int code,float x,float y,float sx,float sy,int color){
        paint.setColor(color);
        paint.setStyle(Paint.Style.FILL);
        int[] g=Font8x8.glyph(code);
        if(!compact){
            for(int r=0;r<8;r++){int bits=g[r];for(int b=0;b<8;b++)
                if((bits&(1<<(7-b)))!=0)c.drawRect(x+b*sx,y+r*sy,x+(b+1)*sx,y+(r+1)*sy,paint);}
        } else {
            for(int r=0;r<8;r++){int bits=g[r];for(int b=0;b<8;b+=2){
                boolean on=((bits&(1<<(7-b)))!=0)||((bits&(1<<(6-b)))!=0);
                if(on)c.drawRect(x+(b/2)*sx,y+r*sy,x+(b/2+1)*sx,y+(r+1)*sy,paint);}}
        }
    }

}
