# Naive BASIC 0.9.6 — launcher icon fix

First unified BASIC screen prototype.
- Android TextView output replaced by BasicScreenView/Canvas.
- Logical screens: SCREEN 0..3.
- Default: landscape 320x240.
- PRINT and PRINT AT.
- Spectrum-like one-screen scrolling.
- 8x8 text cells.
- GIRO sensor value.
- Editor orientation remains Android-controlled.
- Long BACK press (~5s) is the program escape while BASIC is running.

This iteration intentionally does not add graphics primitives yet.


## 0.8.2 — display/orientation fix
- BASIC logical screen remains fixed at 320×240 / 240×320; Android system bars are not treated as BASIC pixels.
- Run screen uses fullscreen while BASIC is running, with aspect-preserving scaling when the physical display is larger.
- RUN switches to landscape and starts the program in one action, including when the editor was in portrait mode.
- Returning from BASIC restores the editor's standard landscape orientation.
- No BASIC commands or interpreter behavior were changed in this fix.

## 0.8.3 — text-only step

Only three planned changes are included:
- 0.1: while a BASIC program is running, BACK exits only after holding it for about 5 seconds;
- 0.2: SCREEN accepts the optional second parameter `SCREEN orientation,charset`,
  where 0 = 8x8 and 1 = 4x8; omitted charset means 8x8;
- 1: `PRINT AT row,col;...` positions text on the logical BASIC screen.

No graphics primitives, TAB, CLS, INK/PAPER, BEEP, PLAY, or other language additions
are included in this iteration.


## 0.8.4 — string functions / GIRO fix

Added and tested in the interpreter:
- `CHR$` — character from numeric code;
- `CODE` — code of the first character;
- `LEN` — string length;
- `STR$` — number to text;
- `VAL` — numeric value from text;
- `INKEY$` — non-waiting key character.

The 0.8.4 build also fixes the internal numeric-expression call used by `CHR$` and `STR$`
and registers the application as version 0.8.4 instead of the previous 0.8.3 metadata.

`CLS` remains intentionally skipped because `SCREEN` already clears the BASIC screen.


### 0.8.4 GIRO fix

- Fixed `GIRO` numeric input: it now returns the value supplied by the Android accelerometer adapter.
- The bundled tutorial now reaches the GIRO example instead of stopping at line 710.
- `SCREEN 1,0` is included in the tutorial as a visible orientation test.
- No other interpreter behavior was changed in this fix.

## Package version 0.8.6

This package is **Naive BASIC 0.8.6**. Android `versionName` is `0.8.6` and `versionCode` is `23`.
This iteration fixes string-array element references such as `S$(0)` and keeps numeric DIM arrays unchanged. The tutorial contains an executable string-array example.


## 0.8.8 — DEFFN / FN
- Added numeric user-defined functions with `DEFFN NAME(X)=expression`.
- Added calls using `FN NAME(argument)`.
- The function parameter is local during evaluation; global numeric variables remain available to the function body.
- Tutorial examples added.
- Android versionName: 0.8.8; versionCode: 24.
\n\n## Package version 0.8.9\nThis package is **Naive BASIC 0.8.9**. Android `versionName` is `0.8.9` and `versionCode` is `26`.\n\n### 0.8.9 — DATA / READ / RESTORE\n- Added DATA, READ and RESTORE.\n- Numeric and string DATA values are supported.\n- DATA is collected before program execution.\n- The tutorial includes executable examples.\n- Fixed the initial implementation error that referenced a nonexistent `programLines` collection.\n

## Версия 0.9.1
Исправлена сборка BEEP/PLAY. Добавлен отсутствовавший генератор тона для BEEP; PLAY теперь корректно обрабатывает пробелы и табуляцию в музыкальной строке. Сохранён второй встроенный учебник `учебник2.bas`. Android `versionName` — 0.9.1, `versionCode` — 28.


## Версия 0.9.2
Исправлены `GOSUB` и `RETURN`. Добавлен стек адресов возврата для подпрограмм.
Оператор `%` в текущей реализации является краткой записью `MOD`, то есть вычисляет остаток от деления: `17%5` даёт `2`. Учебники и `test.bas` приведены в соответствие с фактическим синтаксисом. Android `versionName` — 0.9.2, `versionCode` — 29.


## Версия 0.9.6
- Исправлено подключение значка приложения: `AndroidManifest.xml` теперь явно использует `@drawable/naive_basic_icon`.
- Значок берётся из одного файла `app/src/main/res/drawable/naive_basic_icon.png`.
- Поэтому его можно заменить в проекте другим PNG подходящего размера, не меняя код: после пересборки новый файл попадёт в APK.
- Текущий значок — предоставленный пользователем PNG 192×192 с прозрачным фоном.
- Android `versionName` — `0.9.6`, `versionCode` — `33`.
