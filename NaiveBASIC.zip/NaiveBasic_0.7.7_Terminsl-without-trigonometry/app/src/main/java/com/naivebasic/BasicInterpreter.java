package com.naivebasic;

import java.util.*;

public class BasicInterpreter {
    public interface OutputRefresh { void refreshOutput(String text); }
    public interface InputProvider { String input(String prompt); }
    public interface InputStateProvider extends InputProvider {
        int getKey();
        boolean isTouch();
        int getTouchX();
        int getTouchY();
        int getScreenX();
        int getScreenY();
    }

    private final InputProvider input;
    private OutputRefresh outputRefresh;
    private final Map<String, Double> numbers = new HashMap<String, Double>();
    private final Map<String, String> strings = new HashMap<String, String>();
    private final StringBuilder out = new StringBuilder();
    private final List<Line> program = new ArrayList<Line>();
    private final Map<Integer, Integer> labels = new HashMap<Integer, Integer>();
    private final Stack<ForState> loops = new Stack<ForState>();
    private final Random random = new Random();

    public BasicInterpreter(InputProvider provider) { input = provider; }
    public BasicInterpreter() { this(null); }
    public void setOutputRefresh(OutputRefresh refresh) { outputRefresh = refresh; }

    public String run(String source) {
        numbers.clear(); strings.clear(); out.setLength(0);
        program.clear(); labels.clear(); loops.clear();

        String[] raw = source.replace("\r", "").split("\n");
        for (int i = 0; i < raw.length; i++) {
            try {
                Line l = parseLine(raw[i], i + 1);
                if (l.text.length() > 0) {
                    if (l.number >= 0) {
                        if (labels.containsKey(Integer.valueOf(l.number)))
                            throw new Exception("Duplicate line number");
                        labels.put(Integer.valueOf(l.number), Integer.valueOf(program.size()));
                    }
                    program.add(l);
                }
            } catch (Exception e) {
                error(i + 1, message(e)); return out.toString();
            }
        }

        for (int pc = 0; pc < program.size(); pc++) {
            Line l = program.get(pc);
            String t = l.text.trim();
            String u = t.toUpperCase(Locale.US);
            try {
                if (u.length() == 0 || u.startsWith("REM") || u.startsWith("'")) continue;
                if (u.equals("END") || u.equals("STOP")) break;
                if (isCommand(u, "PRINT")) print(t.substring(5).trim());
                else if (isCommand(u, "INPUT")) doInput(t.substring(5).trim());
                else if (isCommand(u, "GOTO")) pc = jump(t.substring(4).trim()) - 1;
                else if (isCommand(u, "IF")) {
                    Integer x = ifCommand(t);
                    if (x != null) pc = x.intValue() - 1;
                } else if (isCommand(u, "FOR")) startFor(t.substring(3).trim(), pc);
                else if (isCommand(u, "NEXT")) pc = next(t.substring(4).trim(), pc);
                else if (isCommand(u, "RANDOMIZE")) randomize(t.substring(9).trim());
                else if (isCommand(u, "LET")) assign(t.substring(3).trim());
                else if (t.indexOf('=') > 0) assign(t);
                else throw new Exception("Unknown command");
            } catch (Exception e) {
                error(l.sourceLine, message(e)); break;
            }
        }
        return out.toString();
    }

    private String message(Exception e) {
        return e.getMessage() == null ? "Syntax error" : e.getMessage();
    }

    private boolean isCommand(String upper, String command) {
        return upper.startsWith(command) &&
            (upper.length() == command.length() ||
             Character.isWhitespace(upper.charAt(command.length())));
    }

    private void doInput(String name) throws Exception {
        name = normalizeVariable(name);
        String v = input == null ? "" : input.input(name);
        if (v == null) v = "";
        if (name.endsWith("$")) strings.put(name, v);
        else {
            try { numbers.put(name, Double.valueOf(v.trim())); }
            catch (Exception e) { throw new Exception("Number expected"); }
        }
    }

    private String normalizeVariable(String name) throws Exception {
        name = name.trim().toUpperCase(Locale.US);
        if (!name.matches("[A-Z][A-Z0-9_]*\\$?"))
            throw new Exception("Bad variable name");
        return name;
    }

    private Line parseLine(String s, int source) throws Exception {
        String t = s.trim(), rest;
        int p = 0;
        while (p < t.length() && Character.isDigit(t.charAt(p))) p++;
        if (p > 0 && (p == t.length() || Character.isWhitespace(t.charAt(p)))) {
            rest = t.substring(p).trim();
            return new Line(Integer.parseInt(t.substring(0, p)), rest, source);
        }
        return new Line(-1, t, source);
    }

    private int jump(String s) throws Exception {
        int n = (int)new NumExpr(s).parse();
        Integer pc = labels.get(Integer.valueOf(n));
        if (pc == null) throw new Exception("No such line: " + n);
        return pc.intValue();
    }

    private Integer ifCommand(String t) throws Exception {
        String body = t.substring(2).trim();
        int p = findKeyword(body, "THEN");
        if (p < 0) throw new Exception("THEN expected");
        if (!condition(body.substring(0, p).trim())) return null;

        String a = body.substring(p + 4).trim();
        String u = a.toUpperCase(Locale.US);
        if (isCommand(u, "GOTO")) return Integer.valueOf(jump(a.substring(4).trim()));
        if (a.matches("\\d+")) return Integer.valueOf(jump(a));
        executeInline(a);
        return null;
    }

    private void executeInline(String t) throws Exception {
        String u = t.toUpperCase(Locale.US);
        if (isCommand(u, "PRINT")) print(t.substring(5).trim());
        else if (isCommand(u, "LET")) assign(t.substring(3).trim());
        else if (t.indexOf('=') > 0) assign(t);
        else throw new Exception("Unsupported THEN command");
    }

    private boolean condition(String c) throws Exception {
        return new BoolExpr(c).parse();
    }

    private class BoolExpr {
        String s; int p;
        BoolExpr(String x){s=x.trim();}
        boolean parse() throws Exception { boolean v=orExpr(); skip(); if(p!=s.length()) throw new Exception("Unexpected: "+s.charAt(p)); return v; }
        boolean orExpr() throws Exception { boolean v=andExpr(); while(eatWord("OR")) v=v||andExpr(); return v; }
        boolean andExpr() throws Exception { boolean v=notExpr(); while(eatWord("AND")) v=v&&notExpr(); return v; }
        boolean notExpr() throws Exception { if(eatWord("NOT")) return !notExpr(); return atom(); }
        boolean atom() throws Exception {
            skip();
            if(eat('(')){ boolean v=orExpr(); if(!eat(')')) throw new Exception("Missing )"); return v; }
            int save=p; String left=side(); String op=operator();
            if(op==null){p=save; return new NumExpr(side()).parse()!=0;}
            String right=side();
            if(isStringExpression(left)||isStringExpression(right)){
                int q=new ValueExpr(left).parse().compareTo(new ValueExpr(right).parse());
                return op.equals("=")?q==0:op.equals("<>")?q!=0:op.equals("<")?q<0:op.equals(">")?q>0:op.equals("<=")?q<=0:q>=0;
            }
            double x=new NumExpr(left).parse(),y=new NumExpr(right).parse();
            return op.equals("=")?x==y:op.equals("<>")?x!=y:op.equals("<")?x<y:op.equals(">")?x>y:op.equals("<=")?x<=y:x>=y;
        }
        String side(){
            skip(); int a=p,d=0; boolean q=false;
            while(p<s.length()){
                char ch=s.charAt(p); if(ch=='"') q=!q;
                if(!q){ if(ch=='(')d++; else if(ch==')'&&d>0)d--; if(d==0&&(ch=='='||ch=='<'||ch=='>'||wordAt("AND")||wordAt("OR"))) break; }
                p++;
            } return s.substring(a,p).trim();
        }
        String operator(){ skip(); if(p+1<s.length()&&(s.startsWith("<>",p)||s.startsWith("<=",p)||s.startsWith(">=",p))){String x=s.substring(p,p+2);p+=2;return x;} if(p<s.length()&&(s.charAt(p)=='='||s.charAt(p)=='<'||s.charAt(p)=='>')) return String.valueOf(s.charAt(p++)); return null; }
        boolean wordAt(String w){int e=p+w.length();return e<=s.length()&&s.regionMatches(true,p,w,0,w.length())&&(p==0||!Character.isLetterOrDigit(s.charAt(p-1)))&&(e==s.length()||!Character.isLetterOrDigit(s.charAt(e)));}
        void skip(){while(p<s.length()&&Character.isWhitespace(s.charAt(p)))p++;}
        boolean eat(char x){skip();if(p<s.length()&&s.charAt(p)==x){p++;return true;}return false;}
        boolean eatWord(String w){skip();if(wordAt(w)){p+=w.length();return true;}return false;}
    }

    private boolean isStringExpression(String s) {
        return s.indexOf('"') >= 0 || s.indexOf('$') >= 0;
    }

    private void startFor(String s, int pc) throws Exception {
        int eq=s.indexOf('=');
        if(eq<0) throw new Exception("Bad FOR");
        String name=normalizeVariable(s.substring(0,eq));
        if(name.endsWith("$")) throw new Exception("FOR variable must be numeric");
        String rest=s.substring(eq+1).trim();
        int to=findKeyword(rest,"TO");
        if(to<0) throw new Exception("TO expected");
        double start=new NumExpr(rest.substring(0,to).trim()).parse();
        String after=rest.substring(to+2).trim();
        int stepPos=findKeyword(after,"STEP");
        double end,step=1;
        if(stepPos>=0) {
            end=new NumExpr(after.substring(0,stepPos).trim()).parse();
            step=new NumExpr(after.substring(stepPos+4).trim()).parse();
            if(step==0) throw new Exception("STEP cannot be zero");
        } else end=new NumExpr(after).parse();
        numbers.put(name,Double.valueOf(start));
        loops.push(new ForState(name,end,step,pc));
    }

    private int next(String s,int pc)throws Exception{
        if(loops.empty()) throw new Exception("NEXT without FOR");
        ForState f=loops.peek();
        String n=s.trim();
        if(n.length()>0 && !normalizeVariable(n).equals(f.name))
            throw new Exception("Wrong NEXT variable");
        Double old=numbers.get(f.name);
        if(old==null) throw new Exception("Undefined variable: "+f.name);
        double v=old.doubleValue()+f.step;
        numbers.put(f.name,Double.valueOf(v));
        boolean again=f.step>0?v<=f.end:v>=f.end;
        if(again) return f.pc;
        loops.pop(); return pc;
    }

    private void randomize(String s)throws Exception{
        s=s.trim();
        if(s.length()==0) random.setSeed(System.currentTimeMillis());
        else random.setSeed((long)new NumExpr(s).parse());
    }

    private void assign(String t)throws Exception{
        int p=t.indexOf('=');
        if(p<=0) throw new Exception("Assignment expected");
        String n=normalizeVariable(t.substring(0,p));
        String v=t.substring(p+1).trim();
        if(n.endsWith("$")) strings.put(n,new ValueExpr(v).parse());
        else numbers.put(n,Double.valueOf(new NumExpr(v).parse()));
    }

    private void print(String s)throws Exception {
        out.append(new ValueExpr(s).parse()).append('\n');
        if (outputRefresh != null) outputRefresh.refreshOutput(out.toString());
    }

    private int findKeyword(String s,String word){
        String u=s.toUpperCase(Locale.US); boolean quote=false;
        for(int i=0;i<=u.length()-word.length();i++){
            if(u.charAt(i)=='"') quote=!quote;
            if(quote) continue;
            if(u.regionMatches(i,word,0,word.length())){
                boolean left=i==0||Character.isWhitespace(u.charAt(i-1));
                int e=i+word.length();
                boolean right=e==u.length()||Character.isWhitespace(u.charAt(e));
                if(left&&right) return i;
            }
        } return -1;
    }

    private void error(int n,String m){ out.append("ERROR ").append(n).append(": ").append(m).append('\n'); }
    private String fmt(double n){
        if(Double.isNaN(n)||Double.isInfinite(n)) return Double.toString(n);
        return n==Math.rint(n)?Long.toString((long)n):Double.toString(n);
    }

    private class ValueExpr {
        String s;
        ValueExpr(String x){s=x.trim();}
        String parse()throws Exception{
            StringBuilder r=new StringBuilder();
            int start=0, depth=0; boolean quote=false;
            for(int i=0;i<=s.length();i++){
                char ch=i<s.length()?s.charAt(i):'\0';
                if(ch=='"') quote=!quote;
                if(!quote){
                    if(ch=='(') depth++;
                    else if(ch==')'&&depth>0) depth--;
                }
                if(i==s.length() || (!quote&&depth==0&&(ch==';'||ch==','))){
                    String part=s.substring(start,i).trim();
                    if(part.length()==0) throw new Exception("Expression expected");
                    r.append(valuePart(part));
                    if(i<s.length()&&ch==',') r.append(' ');
                    start=i+1;
                }
            }
            if(quote) throw new Exception("Missing quote");
            return r.toString();
        }
        String valuePart(String part)throws Exception{
            // A plain numeric expression must keep '+' as arithmetic.
            if(!part.contains("\"") && !part.toUpperCase(Locale.US).matches(".*[A-Z][A-Z0-9_]*\\$.*"))
                return fmt(new NumExpr(part).parse());
            StringBuilder r=new StringBuilder();
            int start=0; boolean quote=false; int depth=0;
            for(int i=0;i<=part.length();i++){
                char ch=i<part.length()?part.charAt(i):'\0';
                if(ch=='"') quote=!quote;
                if(!quote){ if(ch=='(')depth++; else if(ch==')'&&depth>0)depth--; }
                if(i==part.length()||(!quote&&depth==0&&ch=='+')){
                    String q=part.substring(start,i).trim();
                    if(q.length()==0) throw new Exception("Expression expected");
                    if(q.startsWith("\"")&&q.endsWith("\"")&&q.length()>=2) r.append(q.substring(1,q.length()-1));
                    else if(q.toUpperCase(Locale.US).endsWith("$")){
                        String n=normalizeVariable(q),v=strings.get(n);
                        if(v==null) throw new Exception("Undefined string: "+n);
                        r.append(v);
                    } else r.append(fmt(new NumExpr(q).parse()));
                    start=i+1;
                }
            }
            if(quote) throw new Exception("Missing quote");
            return r.toString();
        }
    }

    private double inputNumber(String name) throws Exception {
        if (!(input instanceof InputStateProvider))
            throw new Exception("Input unavailable");
        InputStateProvider p = (InputStateProvider) input;
        if (name.equals("KEY")) return p.getKey();
        if (name.equals("TOUCH")) return p.isTouch() ? 1 : 0;
        if (name.equals("TOUCHX")) return p.getTouchX();
        if (name.equals("TOUCHY")) return p.getTouchY();
        if (name.equals("SCREENX")) return p.getScreenX();
        if (name.equals("SCREENY")) return p.getScreenY();
        throw new Exception("Unknown input value");
    }

    private class NumExpr {
        String s; int p;
        NumExpr(String x){s=x.trim();}

        double parse()throws Exception{
            double v=add(); skip();
            if(p!=s.length()) throw new Exception("Unexpected: "+s.charAt(p));
            return v;
        }
        double add()throws Exception{
            double v=mul();
            while(true){skip(); if(eat('+'))v+=mul(); else if(eat('-'))v-=mul(); else return v;}
        }
        double mul()throws Exception{
            double v=power();
            while(true){
                skip();
                if(eat('*'))v*=power();
                else if(eat('/')){double d=power();if(d==0)throw new Exception("Division by zero");v/=d;}
                else if(eatWord("MOD")){
                    double d=power();
                    if(d==0) throw new Exception("Division by zero");
                    v=v-Math.floor(v/d)*d;
                }
                else if(eat('%')){
                    double d=power();
                    if(d==0) throw new Exception("Division by zero");
                    v=v-Math.floor(v/d)*d;
                }
                else return v;
            }
        }
        // Right-associative exponentiation: 2^3^2 = 2^(3^2).
        double power()throws Exception{
            double v=unary(); skip();
            if(eat('^')){
                double e=power();
                v=Math.pow(v,e);
                if(Double.isNaN(v)||Double.isInfinite(v)) throw new Exception("Math domain error");
            }
            return v;
        }
        double unary()throws Exception{
            skip(); if(eat('+'))return unary(); if(eat('-'))return -unary(); return factor();
        }
        double factor()throws Exception{
            skip();
            if(eat('(')){double v=add();if(!eat(')'))throw new Exception("Missing )");return v;}

            if(p<s.length()&&(Character.isDigit(s.charAt(p))||s.charAt(p)=='.')){
                int a=p++;
                while(p<s.length()&&(Character.isDigit(s.charAt(p))||s.charAt(p)=='.'))p++;
                try{return Double.parseDouble(s.substring(a,p));}
                catch(Exception e){throw new Exception("Bad number");}
            }

            if(p<s.length()&&Character.isLetter(s.charAt(p))){
                int a=p++;
                while(p<s.length()&&(Character.isLetterOrDigit(s.charAt(p))||s.charAt(p)=='_'))p++;
                String n=s.substring(a,p).toUpperCase(Locale.US);

                if(n.equals("PI")) return Math.PI;
                if(n.equals("SCREENY")) return inputNumber("SCREENY");
                if(n.equals("SCREENX")) return inputNumber("SCREENX");
                if(n.equals("TOUCHY")) return inputNumber("TOUCHY");
                if(n.equals("TOUCHX")) return inputNumber("TOUCHX");
                if(n.equals("TOUCH")) return inputNumber("TOUCH");
                if(n.equals("KEY")) return inputNumber("KEY");
                if(n.equals("RND")) return random.nextDouble();

                skip();
                if(eat('(')){
                    double arg=add();
                    if(n.equals("MOD")){
                        if(!eat(',')) throw new Exception("Comma expected");
                        double arg2=add();
                        if(!eat(')')) throw new Exception("Missing )");
                        if(arg2==0) throw new Exception("Division by zero");
                        return arg-Math.floor(arg/arg2)*arg2;
                    }
                    if(!eat(')')) throw new Exception("Missing )");
                    return function(n,arg);
                }

                Double v=numbers.get(n);
                if(v==null) throw new Exception("Undefined variable: "+n);
                return v.doubleValue();
            }
            throw new Exception("Number expected");
        }

        double function(String n,double x)throws Exception{
            if(n.equals("SIN")) return Math.sin(x);
            if(n.equals("COS")) return Math.cos(x);
            if(n.equals("TAN")) return Math.tan(x);
            if(n.equals("COT")){
                double y=Math.tan(x);
                if(Math.abs(y)<1e-15) throw new Exception("Division by zero");
                return 1.0/y;
            }
            if(n.equals("ASN")){
                if(x<-1||x>1) throw new Exception("Math domain error");
                return Math.asin(x);
            }
            if(n.equals("ACS")){
                if(x<-1||x>1) throw new Exception("Math domain error");
                return Math.acos(x);
            }
            if(n.equals("ATN")) return Math.atan(x);
            if(n.equals("EXP")){
                double y=Math.exp(x);
                if(Double.isInfinite(y)) throw new Exception("Math domain error");
                return y;
            }
            if(n.equals("LN")){
                if(x<=0) throw new Exception("Math domain error");
                return Math.log(x);
            }
            if(n.equals("SQR")){
                if(x<0) throw new Exception("Math domain error");
                return Math.sqrt(x);
            }
            if(n.equals("ABS")) return Math.abs(x);
            if(n.equals("INT")) return Math.floor(x);
            if(n.equals("SGN")) return x>0?1:x<0?-1:0;
            throw new Exception("Unknown function: "+n);
        }

        void skip(){while(p<s.length()&&Character.isWhitespace(s.charAt(p)))p++;}
        boolean eatWord(String word){
            skip();
            int e=p+word.length();
            if(e<=s.length() && s.regionMatches(true,p,word,0,word.length()) &&
                    (p==0 || !Character.isLetterOrDigit(s.charAt(p-1))) &&
                    (e==s.length() || !Character.isLetterOrDigit(s.charAt(e)))){
                p=e; return true;
            }
            return false;
        }
        boolean eat(char c){skip();if(p<s.length()&&s.charAt(p)==c){p++;return true;}return false;}
    }

    private static class Line {
        int number; String text; int sourceLine;
        Line(int n,String t,int s){number=n;text=t;sourceLine=s;}
    }
    private static class ForState {
        String name; double end,step; int pc;
        ForState(String n,double e,double st,int p){name=n;end=e;step=st;pc=p;}
    }
}
