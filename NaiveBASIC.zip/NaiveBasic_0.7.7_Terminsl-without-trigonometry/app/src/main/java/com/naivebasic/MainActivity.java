package com.naivebasic;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.text.method.ScrollingMovementMethod;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.Collections;

public class MainActivity extends Activity implements BasicInterpreter.InputStateProvider {
    private int lastKey = 0;
    private boolean touchDown = false;
    private volatile boolean programRunning = false;
    private int touchX = 0;
    private int touchY = 0;

    private EditText editor;
    private TextView output;
    private View editorScreen;
    private View runScreen;
    private String pendingInput = "";
    private View aboutScreen;

    public void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.main);
        installBundledPrograms();

        editorScreen = findViewById(R.id.editor_screen);
        runScreen = findViewById(R.id.run_screen);
        aboutScreen = findViewById(R.id.about_screen);
        editor = (EditText)findViewById(R.id.editor);
        output = (TextView)findViewById(R.id.output);
        output.setMovementMethod(ScrollingMovementMethod.getInstance());

        editor.setText(
            "10 REM Naive BASIC 0.6\n" +
            "20 PRINT \"HELLO, WORLD!\"\n" +
            "30 FOR I=1 TO 5\n" +
            "40 PRINT \"COUNT: \" + I\n" +
            "50 NEXT I\n" +
            "60 END\n"
        );

        ((Button)findViewById(R.id.run)).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { runProgram(); }
        });
        ((Button)findViewById(R.id.menu)).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { showMainMenu(); }
        });

        editor.setFocusableInTouchMode(true);
        editor.setOnKeyListener(new View.OnKeyListener() {
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (event.getAction() == KeyEvent.ACTION_DOWN) {
                    lastKey = spectrumKeyCode(keyCode);
                }
                return false;
            }
        });
        runScreen.setFocusableInTouchMode(true);
        runScreen.setOnKeyListener(new View.OnKeyListener() {
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (event.getAction() == KeyEvent.ACTION_DOWN) lastKey = spectrumKeyCode(keyCode);
                return false;
            }
        });
        runScreen.setOnTouchListener(new View.OnTouchListener() {
            public boolean onTouch(View v, MotionEvent event) {
                touchX = (int)event.getX();
                touchY = (int)event.getY();
                touchDown = event.getAction() != MotionEvent.ACTION_UP &&
                             event.getAction() != MotionEvent.ACTION_CANCEL;
                if (event.getAction() == MotionEvent.ACTION_UP && !programRunning) {
                    returnToEditor();
                }
                return true;
            }
        });
        aboutScreen.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { returnToEditor(); }
        });

        showEditor();
    }

    private void installBundledPrograms() {
        String name = "uchebnik.bas";
        if (new File(getFilesDir(), name).exists()) return;
        try {
            java.io.InputStream in = getAssets().open("programs/" + name);
            FileOutputStream out = openFileOutput(name, MODE_PRIVATE);
            byte[] buffer = new byte[4096];
            int n;
            while ((n = in.read(buffer)) > 0) out.write(buffer, 0, n);
            in.close();
            out.close();
        } catch (Exception ignored) {
        }
    }

    private void showEditor() {
        editorScreen.setVisibility(View.VISIBLE);
        runScreen.setVisibility(View.GONE);
        aboutScreen.setVisibility(View.GONE);
    }

    private void showRunScreen() {
        editorScreen.setVisibility(View.GONE);
        aboutScreen.setVisibility(View.GONE);
        runScreen.setVisibility(View.VISIBLE);
        output.setVisibility(View.VISIBLE);
        runScreen.bringToFront();
        runScreen.requestLayout();
        runScreen.invalidate();
    }

    private void showAbout() {
        editorScreen.setVisibility(View.GONE);
        runScreen.setVisibility(View.GONE);
        aboutScreen.setVisibility(View.VISIBLE);
    }

    private void returnToEditor() {
        showEditor();
    }

    public int getKey() {
        int k = lastKey;
        lastKey = 0;
        return k;
    }

    public boolean isTouch() { return touchDown; }
    public int getTouchX() { return touchX; }
    public int getTouchY() { return touchY; }
    public int getScreenX() { return runScreen.getWidth(); }
    public int getScreenY() { return runScreen.getHeight(); }

    private int spectrumKeyCode(int k) {
        switch(k) {
            case KeyEvent.KEYCODE_0: return 48;
            case KeyEvent.KEYCODE_1: return 49;
            case KeyEvent.KEYCODE_2: return 50;
            case KeyEvent.KEYCODE_3: return 51;
            case KeyEvent.KEYCODE_4: return 52;
            case KeyEvent.KEYCODE_5: return 53;
            case KeyEvent.KEYCODE_6: return 54;
            case KeyEvent.KEYCODE_7: return 55;
            case KeyEvent.KEYCODE_8: return 56;
            case KeyEvent.KEYCODE_9: return 57;
            case KeyEvent.KEYCODE_DPAD_LEFT: return 8;
            case KeyEvent.KEYCODE_DPAD_RIGHT: return 9;
            case KeyEvent.KEYCODE_DPAD_UP: return 10;
            case KeyEvent.KEYCODE_DPAD_DOWN: return 11;
            case KeyEvent.KEYCODE_ENTER: return 13;
            case KeyEvent.KEYCODE_DEL: return 127;
            case KeyEvent.KEYCODE_SPACE: return 32;
            default: return k;
        }
    }

    public void onBackPressed() {
        if (runScreen.getVisibility() == View.VISIBLE ||
                aboutScreen.getVisibility() == View.VISIBLE) {
            returnToEditor();
        } else {
            super.onBackPressed();
        }
    }

    private void runProgram() {
        output.setText("");
        lastKey = 0;
        touchDown = false;
        programRunning = true;
        showRunScreen();
        runScreen.requestFocus();

        new Thread(new Runnable() {
            public void run() {
                BasicInterpreter interpreter = new BasicInterpreter(MainActivity.this);
                interpreter.setOutputRefresh(new BasicInterpreter.OutputRefresh() {
                    public void refreshOutput(final String text) {
                        runOnUiThread(new Runnable() {
                            public void run() {
                                output.setText(text);
                                if (output.getLayout() != null) {
                                    int bottom = output.getLayout().getLineBottom(output.getLineCount() - 1);
                                    int scroll = bottom - output.getHeight();
                                    if (scroll < 0) scroll = 0;
                                    output.scrollTo(0, scroll);
                                }
                            }
                        });
                    }
                });
                final String result = interpreter.run(editor.getText().toString());
                runOnUiThread(new Runnable() {
                    public void run() {
                        programRunning = false;
                        output.setVisibility(View.VISIBLE);
                        output.setText(result);
                        output.requestLayout();
                        output.invalidate();
                        runScreen.requestLayout();
                        runScreen.invalidate();
                        runScreen.postDelayed(new Runnable() {
                            public void run() {
                                output.setVisibility(View.VISIBLE);
                                output.invalidate();
                                runScreen.invalidate();
                            }
                        }, 80);
                    }
                });
            }
        }).start();
    }

    private void showMainMenu() {
        final String[] items = {
            "NEW",
            "SAVE",
            "LOAD",
            "DELETE",
            "AUTHORS"
        };

        new AlertDialog.Builder(this)
            .setTitle("PROGRAM")
            .setItems(items, new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface d, int which) {
                    if (which == 0) {
                        editor.setText("");
                    } else if (which == 1) {
                        askSaveName();
                    } else if (which == 2) {
                        showProgramList(false);
                    } else if (which == 3) {
                        showProgramList(true);
                    } else if (which == 4) {
                        showAbout();
                    }
                }
            })
            .show();
    }

    private void askSaveName() {
        final EditText field = new EditText(this);
        field.setSingleLine(true);
        field.setText("PROGRAM.bas");
        field.setSelectAllOnFocus(true);
        field.requestFocus();
        field.setSelection(0, field.getText().length());

        new AlertDialog.Builder(this)
            .setTitle("SAVE PROGRAM")
            .setMessage("Program name")
            .setView(field)
            .setPositiveButton("SAVE", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface d, int which) {
                    String name = normalizeName(field.getText().toString());
                    if (name == null) {
                        showEditorMessage("ERROR: BAD FILE NAME");
                        return;
                    }
                    try {
                        saveProgram(name);
                        showEditorMessage("SAVED: " + name);
                    } catch (Exception e) {
                        showEditorMessage("ERROR: " + e.getMessage());
                    }
                }
            })
            .setNegativeButton("CANCEL", null)
            .show();
    }

    private void showProgramList(final boolean deleteMode) {
        final String[] names = getProgramNames();
        if (names.length == 0) {
            showEditorMessage("NO PROGRAMS");
            return;
        }

        new AlertDialog.Builder(this)
            .setTitle(deleteMode ? "DELETE PROGRAM" : "LOAD PROGRAM")
            .setItems(names, new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface d, int which) {
                    if (deleteMode) deleteProgram(names[which]);
                    else loadProgram(names[which]);
                }
            })
            .setNegativeButton("CANCEL", null)
            .show();
    }

    private void showEditorMessage(String message) {
        new AlertDialog.Builder(this)
            .setMessage(message)
            .setPositiveButton("OK", null)
            .show();
    }

    private void loadProgram(String name) {
        try {
            FileInputStream in = openFileInput(name);
            StringBuilder text = new StringBuilder();
            byte[] buffer = new byte[4096];
            int n;
            while ((n = in.read(buffer)) > 0)
                text.append(new String(buffer, 0, n, "UTF-8"));
            in.close();

            editor.setText(text.toString());
            showEditorMessage("LOADED: " + name);
        } catch (Exception e) {
            showEditorMessage("ERROR: " + e.getMessage());
        }
    }

    private void saveProgram(String name) throws Exception {
        FileOutputStream out = openFileOutput(name, MODE_PRIVATE);
        out.write(editor.getText().toString().getBytes("UTF-8"));
        out.close();
    }

    private void deleteProgram(final String name) {
        new AlertDialog.Builder(this)
            .setTitle("DELETE")
            .setMessage("Delete " + name + "?")
            .setPositiveButton("DELETE", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface d, int which) {
                    showEditorMessage(deleteFile(name)
                        ? "DELETED: " + name : "DELETE FAILED");
                }
            })
            .setNegativeButton("CANCEL", null)
            .show();
    }

    private String[] getProgramNames() {
        String[] all = getFilesDir().list();
        ArrayList<String> result = new ArrayList<String>();
        if (all != null) {
            for (int i = 0; i < all.length; i++)
                if (all[i].toLowerCase().endsWith(".bas"))
                    result.add(all[i]);
        }
        Collections.sort(result);
        return result.toArray(new String[result.size()]);
    }

    private String normalizeName(String raw) {
        String name = raw == null ? "" : raw.trim();
        if (name.length() == 0) name = "PROGRAM.bas";
        if (!name.toLowerCase().endsWith(".bas")) name += ".bas";
        if (!name.matches("[A-Za-z0-9._-]+\\.bas")) return null;
        if (name.length() > 64) return null;
        return name;
    }

    public String input(final String prompt) {
        pendingInput = "";
        final Object lock = this;

        runOnUiThread(new Runnable() {
            public void run() {
                final EditText field = new EditText(MainActivity.this);
                field.setSingleLine(true);

                new AlertDialog.Builder(MainActivity.this)
                    .setTitle("INPUT")
                    .setMessage(prompt)
                    .setView(field)
                    .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface d, int w) {
                            synchronized(lock) {
                                pendingInput = field.getText().toString();
                                lock.notify();
                            }
                        }
                    })
                    .setNegativeButton("CANCEL", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface d, int w) {
                            synchronized(lock) {
                                pendingInput = "";
                                lock.notify();
                            }
                        }
                    })
                    .setOnCancelListener(new DialogInterface.OnCancelListener() {
                        public void onCancel(DialogInterface d) {
                            synchronized(lock) { lock.notify(); }
                        }
                    }).show();
            }
        });

        synchronized(lock) {
            try { lock.wait(); }
            catch (InterruptedException e) { Thread.currentThread().interrupt(); }
        }
        return pendingInput;
    }
}