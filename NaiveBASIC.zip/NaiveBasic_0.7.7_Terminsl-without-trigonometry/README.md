# Naive BASIC 0.7.3

Added executable Russian tutorial: programs/uchebnik.bas.
Project history/specification is included and updated every iteration.
