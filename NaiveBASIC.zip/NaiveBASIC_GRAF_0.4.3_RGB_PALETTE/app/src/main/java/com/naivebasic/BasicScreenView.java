package com.naivebasic;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Looper;
import android.util.AttributeSet;
import android.view.View;

public class BasicScreenView extends View {
    private final Paint paint = new Paint();
    private Bitmap bitmap;

    private int mode=0;
    private boolean compact=false;
    private int frameWidth=320, frameHeight=240;
    private int cols=40, rows=30, cellW=8, cellH=8;
    private int cursorX=0, cursorY=0;
    private int plotX=0, plotY=0;
    private int inkColor=7, paperColor=0;

    // Bitmap is the screen. No persistent second framebuffer exists.
    private byte[] colorIndexBuffer = new byte[320*320];
    private int[] cellPixels = new int[64];
    private int[] scrollPixels = new int[320*320];
    private int[] fillQueueX = new int[320*320];
    private int[] fillQueueY = new int[320*320];

    public BasicScreenView(Context c, AttributeSet a){
        super(c,a);
        paint.setAntiAlias(false);
        paint.setFilterBitmap(false);
        setFocusable(true);
        configureFrame();
        clear();
    }

    public BasicScreenView(Context c){this(c,null);}

    private int viewportW(){ return (mode==1||mode==3)?240:320; }
    private int viewportH(){ return (mode==1||mode==3)?320:240; }
    private float scaleX(){ return getWidth()/(float)frameWidth; }
    private float scaleY(){ return getHeight()/(float)frameHeight; }
    private int clamp(int v,int a,int b){ return v<a?a:(v>b?b:v); }

    private void refresh(){
        if(Looper.myLooper()==Looper.getMainLooper()) invalidate();
        else postInvalidate();
    }

    private void configureFrame(){
        frameWidth=viewportW();
        frameHeight=viewportH();
        updateGrid();
        if(bitmap!=null && !bitmap.isRecycled()) bitmap.recycle();
        bitmap=Bitmap.createBitmap(frameWidth,frameHeight,Bitmap.Config.ARGB_8888);
        colorIndexBuffer=new byte[320*320];
    }

    private void updateGrid(){
        if(mode==1||mode==3){
            cols=compact?60:30;
            rows=40;
        }else{
            cols=compact?80:40;
            rows=30;
        }
        cellW=compact?4:8;
        cellH=8;
    }

    public void resetScreen(){ setScreenMode(0,compact); }
    public void setScreenMode(int m){ setScreenMode(m,compact); }

    public synchronized void setScreenMode(int m, boolean c){
        mode=m;
        compact=c;
        configureFrame();
        cursorX=0; cursorY=0; plotX=0; plotY=0;
        clear();
    }

    public synchronized void setCompact(boolean on){
        compact=on;
        configureFrame();
        cursorX=0; cursorY=0; plotX=0; plotY=0;
        clear();
    }

    public synchronized void clear(){
        bitmap.eraseColor(palette(paperColor));
        java.util.Arrays.fill(colorIndexBuffer,(byte)(paperColor&255));
        cursorX=0; cursorY=0; plotX=0; plotY=0;
        refresh();
    }

    public synchronized void clearScreen(){ clear(); }

    public synchronized void setInkColor(int c){ inkColor=clamp(c,0,255); }
    public synchronized void setPaperColor(int c){ paperColor=clamp(c,0,255); }

    public synchronized void tab(int n){
        if(n<0)n=0;
        cursorX+=n;
        while(cursorX>=cols) newline();
        refresh();
    }

    public synchronized void printAt(int row,int col,String s){
        cursorY=clamp(row,0,rows-1);
        cursorX=clamp(col,0,cols-1);
        printText(s);
    }

    public synchronized void printText(String s){
        if(s==null)return;
        String[] parts=s.replace("\r","").split("\n",-1);
        for(int p=0;p<parts.length;p++){
            String line=parts[p];
            for(int i=0;i<line.length();i++){
                char ch=line.charAt(i);
                if(ch=='\t'){
                    cursorX=(cursorX+4)&~3;
                    if(cursorX>=cols)newline();
                    continue;
                }
                putChar(ch);
            }
            if(p<parts.length-1)newline();
        }
        refresh();
    }

    private void putChar(char ch){
        if(cursorX>=cols)newline();
        if(cursorY>=rows)cursorY=rows-1;

        int code=encode(ch);
        int baseX=cursorX*cellW;
        int baseY=cursorY*cellH;
        int ink=palette(inkColor);
        int paper=palette(paperColor);

        int needed=cellW*8;
        if(cellPixels.length<needed) cellPixels=new int[needed];

        int[] glyph=Font8x8.glyph(code);
        for(int ry=0;ry<8;ry++){
            int bits=glyph[ry];
            for(int rx=0;rx<cellW;rx++){
                boolean on;
                if(compact){
                    int b1=7-rx*2, b2=6-rx*2;
                    on=((bits&(1<<b1))!=0)||((bits&(1<<b2))!=0);
                }else{
                    on=(bits&(1<<(7-rx)))!=0;
                }
                cellPixels[ry*cellW+rx]=on?ink:paper;
            }
        }
        bitmap.setPixels(cellPixels,0,cellW,baseX,baseY,cellW,8);
        for(int ry=0;ry<8;ry++){
            int bits=glyph[ry];
            for(int rx=0;rx<cellW;rx++){
                boolean on;
                if(compact){
                    int b1=7-rx*2,b2=6-rx*2;
                    on=((bits&(1<<b1))!=0)||((bits&(1<<b2))!=0);
                }else on=(bits&(1<<(7-rx)))!=0;
                colorIndexBuffer[(baseY+ry)*320+(baseX+rx)]=(byte)(on?inkColor:paperColor);
            }
        }

        cursorX++;
        if(cursorX>=cols)newline();
    }

    private void newline(){
        cursorX=0;
        cursorY++;
        if(cursorY>=rows){
            scrollUp(cellH);
            cursorY=rows-1;
        }
    }

    private void scrollUp(int pixels){
        int w=frameWidth, h=frameHeight;
        if(pixels<=0 || pixels>=h){
            bitmap.eraseColor(palette(paperColor));
            return;
        }

        int rowsToCopy=h-pixels;
        int n=w*rowsToCopy;
        if(scrollPixels.length<n)scrollPixels=new int[n];

        bitmap.getPixels(scrollPixels,0,w,0,pixels,w,rowsToCopy);
        bitmap.setPixels(scrollPixels,0,w,0,0,w,rowsToCopy);
        for(int y=0;y<rowsToCopy;y++)
            System.arraycopy(colorIndexBuffer,(y+pixels)*320,colorIndexBuffer,y*320,w);


        // Clear only the exposed bottom strip.
        int paper=palette(paperColor);
        for(int y=h-pixels;y<h;y++){
            for(int x=0;x<w;x++){ bitmap.setPixel(x,y,paper); colorIndexBuffer[y*320+x]=(byte)(paperColor&255); }
        }
    }

    public synchronized void plotPoint(int x,int y,int color){
        if(x<0||y<0||x>=frameWidth||y>=frameHeight)return;
        int cc=clamp(color,0,255); bitmap.setPixel(x,y,palette(cc)); colorIndexBuffer[y*320+x]=(byte)cc;
        plotX=x; plotY=y;
        refresh();
    }

    public synchronized void draw(int dx,int dy,int color)throws Exception{
        int x1=plotX+dx,y1=plotY+dy;
        if(x1<0||x1>=frameWidth||y1<0||y1>=frameHeight)
            throw new Exception("DRAW coordinate out of range");
        drawLineInternal(plotX,plotY,x1,y1,color);
    }

    public synchronized void drawLine(int x1,int y1,int x2,int y2){
        drawLineInternal(x1,y1,x2,y2,inkColor);
    }

    public synchronized void drawLineTo(int x2,int y2){
        drawLineInternal(plotX,plotY,x2,y2,inkColor);
    }

    private void drawLineInternal(int x1,int y1,int x2,int y2,int color){
        if(x1<0||x1>=frameWidth||y1<0||y1>=frameHeight||
           x2<0||x2>=frameWidth||y2<0||y2>=frameHeight)return;

        int dx=Math.abs(x2-x1),sx=x1<x2?1:-1;
        int dy=-Math.abs(y2-y1),sy=y1<y2?1:-1;
        int err=dx+dy;
        int rgb=palette(clamp(color,0,255));

        while(true){
            bitmap.setPixel(x1,y1,rgb); colorIndexBuffer[y1*320+x1]=(byte)(color&255);
            if(x1==x2&&y1==y2)break;
            int e2=2*err;
            if(e2>=dy){err+=dy;x1+=sx;}
            if(e2<=dx){err+=dx;y1+=sy;}
        }
        plotX=x2;plotY=y2;
        refresh();
    }

    public synchronized void circle(int xc,int yc,int rx,int ry,boolean filled)throws Exception{
        rx=Math.abs(rx);
        ry=Math.abs(ry);
        int rgb=palette(inkColor);

        // Clipping is intentional: a circle/ellipse may extend outside SCREEN.
        if(rx==0 && ry==0){
            if(xc>=0 && xc<frameWidth && yc>=0 && yc<frameHeight){
                bitmap.setPixel(xc,yc,rgb);
                colorIndexBuffer[yc*320+xc]=(byte)(inkColor&255);
            }
        }else if(filled){
            int y0=Math.max(0,yc-ry);
            int y1=Math.min(frameHeight-1,yc+ry);
            for(int y=y0;y<=y1;y++){
                double q=ry==0?1.0:
                    1.0-(double)((y-yc)*(y-yc))/(double)(ry*ry);
                if(q<0)continue;
                int span=rx==0?0:(int)Math.round(rx*Math.sqrt(q));
                int x0=Math.max(0,xc-span);
                int x1=Math.min(frameWidth-1,xc+span);
                for(int x=x0;x<=x1;x++){
                    bitmap.setPixel(x,y,rgb);
                    colorIndexBuffer[y*320+x]=(byte)(inkColor&255);
                }
            }
        }else{
            if(rx==0){
                int y0=Math.max(0,yc-ry);
                int y1=Math.min(frameHeight-1,yc+ry);
                for(int y=y0;y<=y1;y++){
                    if(xc>=0&&xc<frameWidth){
                        bitmap.setPixel(xc,y,rgb);
                        colorIndexBuffer[y*320+xc]=(byte)(inkColor&255);
                    }
                }
            }else if(ry==0){
                int x0=Math.max(0,xc-rx);
                int x1=Math.min(frameWidth-1,xc+rx);
                if(yc>=0&&yc<frameHeight){
                    for(int x=x0;x<=x1;x++){
                        bitmap.setPixel(x,yc,rgb);
                        colorIndexBuffer[yc*320+x]=(byte)(inkColor&255);
                    }
                }
            }else{
                for(int dx=-rx;dx<=rx;dx++){
                    double q=1.0-(double)(dx*dx)/(double)(rx*rx);
                    if(q<0)continue;
                    int dy=(int)Math.round(ry*Math.sqrt(q));
                    int x=xc+dx;
                    int yTop=yc-dy;
                    int yBottom=yc+dy;
                    if(x>=0&&x<frameWidth){
                        if(yTop>=0&&yTop<frameHeight){
                            bitmap.setPixel(x,yTop,rgb);
                            colorIndexBuffer[yTop*320+x]=(byte)(inkColor&255);
                        }
                        if(yBottom>=0&&yBottom<frameHeight){
                            bitmap.setPixel(x,yBottom,rgb);
                            colorIndexBuffer[yBottom*320+x]=(byte)(inkColor&255);
                        }
                    }
                }
                for(int dy=-ry;dy<=ry;dy++){
                    double q=1.0-(double)(dy*dy)/(double)(ry*ry);
                    if(q<0)continue;
                    int dx=(int)Math.round(rx*Math.sqrt(q));
                    int y=yc+dy;
                    int xLeft=xc-dx;
                    int xRight=xc+dx;
                    if(y>=0&&y<frameHeight){
                        if(xLeft>=0&&xLeft<frameWidth){
                            bitmap.setPixel(xLeft,y,rgb);
                            colorIndexBuffer[y*320+xLeft]=(byte)(inkColor&255);
                        }
                        if(xRight>=0&&xRight<frameWidth){
                            bitmap.setPixel(xRight,y,rgb);
                            colorIndexBuffer[y*320+xRight]=(byte)(inkColor&255);
                        }
                    }
                }
            }
        }
        refresh();
    }

    public synchronized void triangle(int x1,int y1,int x2,int y2,int x3,int y3,boolean filled)throws Exception{
        if(x1<0||x1>=frameWidth||y1<0||y1>=frameHeight||
           x2<0||x2>=frameWidth||y2<0||y2>=frameHeight||
           x3<0||x3>=frameWidth||y3<0||y3>=frameHeight)
            throw new Exception("TRIANGLE coordinate out of range");

        if(!filled){
            drawLineInternal(x1,y1,x2,y2,inkColor);
            drawLineInternal(x2,y2,x3,y3,inkColor);
            drawLineInternal(x3,y3,x1,y1,inkColor);
        }else{
            int minY=Math.min(y1,Math.min(y2,y3));
            int maxY=Math.max(y1,Math.max(y2,y3));
            for(int y=minY;y<=maxY;y++){
                int[] xs=new int[3];
                int count=0;
                count=addIntersection(xs,count,x1,y1,x2,y2,y);
                count=addIntersection(xs,count,x2,y2,x3,y3,y);
                count=addIntersection(xs,count,x3,y3,x1,y1,y);
                if(count>=2){
                    java.util.Arrays.sort(xs,0,count);
                    for(int x=xs[0];x<=xs[count-1];x++) bitmap.setPixel(x,y,palette(inkColor));
                }
            }
            plotX=x3;plotY=y3;
            refresh();
        }
    }

    private int addIntersection(int[] xs,int count,int x1,int y1,int x2,int y2,int y){
        if(y1==y2)return count;
        int ymin=Math.min(y1,y2),ymax=Math.max(y1,y2);
        if(y<ymin||y>=ymax)return count;
        int x=(int)Math.round(x1+(double)(y-y1)*(x2-x1)/(double)(y2-y1));
        if(count<3)xs[count++]=x;
        return count;
    }

    public synchronized int point(int x,int y)throws Exception{
        if(x<0||x>=frameWidth||y<0||y>=frameHeight)
            throw new Exception("POINT coordinate out of range");
        return colorIndexBuffer[y*320+x]&255;
    }

    public synchronized void paintArea(int x,int y)throws Exception{
        if(x<0||x>=frameWidth||y<0||y>=frameHeight)
            throw new Exception("PAINT coordinate out of range");

        int target=bitmap.getPixel(x,y);
        int replacement=palette(inkColor);
        if(target==replacement)return;

        int w=frameWidth,h=frameHeight;
        int max=w*h;
        if(fillQueueX.length<max){
            fillQueueX=new int[max];
            fillQueueY=new int[max];
        }

        int head=0,tail=0;
        fillQueueX[tail]=x;fillQueueY[tail]=y;tail++;
        bitmap.setPixel(x,y,replacement); colorIndexBuffer[y*320+x]=(byte)(inkColor&255);

        while(head<tail){
            int cx=fillQueueX[head],cy=fillQueueY[head++];

            if(cx>0&&bitmap.getPixel(cx-1,cy)==target){
                bitmap.setPixel(cx-1,cy,replacement);
                fillQueueX[tail]=cx-1;fillQueueY[tail++]=cy;
            }
            if(cx+1<w&&bitmap.getPixel(cx+1,cy)==target){
                bitmap.setPixel(cx+1,cy,replacement);
                fillQueueX[tail]=cx+1;fillQueueY[tail++]=cy;
            }
            if(cy>0&&bitmap.getPixel(cx,cy-1)==target){
                bitmap.setPixel(cx,cy-1,replacement);
                fillQueueX[tail]=cx;fillQueueY[tail++]=cy-1;
            }
            if(cy+1<h&&bitmap.getPixel(cx,cy+1)==target){
                bitmap.setPixel(cx,cy+1,replacement);
                fillQueueX[tail]=cx;fillQueueY[tail++]=cy+1;
            }
        }
        refresh();
    }

    public boolean hasOutput(String s){ return s!=null && s.length()>0; }

    public int logicalX(int px){ return clamp((int)(px/scaleX()),0,frameWidth-1); }
    public int logicalY(int py){ return clamp((int)(py/scaleY()),0,frameHeight-1); }

    private int encode(char c){
        if(c<256)return c;
        switch(c){
            case 'А':return 0xE1;case 'Б':return 0xE2;case 'В':return 0xF7;case 'Г':return 0xE7;
            case 'Д':return 0xE4;case 'Е':return 0xE5;case 'Ё':return 0xB3;case 'Ж':return 0xF6;
            case 'З':return 0xFA;case 'И':return 0xE9;case 'Й':return 0xEA;case 'К':return 0xEB;
            case 'Л':return 0xEC;case 'М':return 0xED;case 'Н':return 0xEE;case 'О':return 0xEF;
            case 'П':return 0xF0;case 'Р':return 0xF2;case 'С':return 0xF3;case 'Т':return 0xF4;
            case 'У':return 0xF5;case 'Ф':return 0xE6;case 'Х':return 0xE8;case 'Ц':return 0xE3;
            case 'Ч':return 0xFE;case 'Ш':return 0xFB;case 'Щ':return 0xFD;case 'Ъ':return 0xFF;
            case 'Ы':return 0xF9;case 'Ь':return 0xF8;case 'Э':return 0xFC;case 'Ю':return 0xE0;case 'Я':return 0xF1;
            case 'а':return 0xC1;case 'б':return 0xC2;case 'в':return 0xD7;case 'г':return 0xC7;
            case 'д':return 0xC4;case 'е':return 0xC5;case 'ё':return 0xA3;case 'ж':return 0xD6;
            case 'з':return 0xDA;case 'и':return 0xC9;case 'й':return 0xCA;case 'к':return 0xCB;
            case 'л':return 0xCC;case 'м':return 0xCD;case 'н':return 0xCE;case 'о':return 0xCF;
            case 'п':return 0xD0;case 'р':return 0xD2;case 'с':return 0xD3;case 'т':return 0xD4;
            case 'у':return 0xD5;case 'ф':return 0xC6;case 'х':return 0xC8;case 'ц':return 0xC3;
            case 'ч':return 0xDE;case 'ш':return 0xDB;case 'щ':return 0xDD;case 'ъ':return 0xDF;
            case 'ы':return 0xD9;case 'ь':return 0xD8;case 'э':return 0xDC;case 'ю':return 0xC0;case 'я':return 0xD1;
            default:return '?';
        }
    }

    @Override
    protected synchronized void onDraw(Canvas c){
        super.onDraw(c);
        if(bitmap==null || bitmap.isRecycled()) return;
        c.drawBitmap(bitmap,null,
            new android.graphics.RectF(0,0,
                frameWidth*scaleX(),frameHeight*scaleY()),
            paint);
    }

    private int palette(int index){
        int v=index&255;

        // Final RGB palette layout:
        // 128/64 = RED
        // 32/16  = GREEN
        // 8/4    = BLUE
        // 2/1    = COMMON BRIGHTNESS
        //
        // Each RGB channel is 8 bits:
        //   [2 colour bits][0000][2 brightness bits expanded]
        //
        // Common brightness expansion:
        //   00 -> 000000
        //   01 -> 011111
        //   10 -> 100000
        //   11 -> 111111
        //
        // Therefore:
        //   R = RR0000LL
        //   G = GG0000LL
        //   B = BB0000LL
        //
        // 0x00 -> #000000
        // 0xFF -> #FFFFFF
        int rPair=(v>>6)&3;
        int gPair=(v>>4)&3;
        int bPair=(v>>2)&3;
        int lumPair=v&3;

        int low;
        switch(lumPair){
            case 0:  low=0;  break;   // 000000
            case 1:  low=31; break;  // 011111
            case 2:  low=32; break;  // 100000
            default: low=63; break;  // 111111
        }

        int r=(rPair<<6)|low;
        int g=(gPair<<6)|low;
        int b=(bPair<<6)|low;

        return Color.rgb(r,g,b);
    }
}
